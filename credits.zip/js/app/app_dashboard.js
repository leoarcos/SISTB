const electronApp= require('electron').remote;
const fs= require('fs');
const Excel = require('Excel4node');

const ipc = require('electron').ipcRenderer;

const usuario=JSON.parse(localStorage.getItem('user'));
const consultasanoactual=[];
const cosnsultaspendientecargar=[];
const pacientesSinCargar=[];

const generales= JSON.parse(fs.readFileSync(__dirname+'/json/consultas_generales.json', 'utf-8'));
const enfermeria= JSON.parse(fs.readFileSync(__dirname+'/json/consultas_enfermeria.json', 'utf-8'));
const psicologia= JSON.parse(fs.readFileSync(__dirname+'/json/consultas_psicologia.json', 'utf-8'));
const nutricional= JSON.parse(fs.readFileSync(__dirname+'/json/consultas_nutricional.json', 'utf-8'));
const adulto= JSON.parse(fs.readFileSync(__dirname+'/json/consultas_adulto.json', 'utf-8'));
const menor= JSON.parse(fs.readFileSync(__dirname+'/json/consultas_menor.json', 'utf-8'));
const gestante= JSON.parse(fs.readFileSync(__dirname+'/json/consultas_gestaciones.json', 'utf-8'));
 	
const pacientes= JSON.parse(fs.readFileSync(__dirname+'/json/pacientes.json', 'utf-8'));
const procedimientos= JSON.parse(fs.readFileSync(__dirname+'/json/procedimientos.json', 'utf-8'));

const iso3166= JSON.parse(fs.readFileSync(__dirname+'/json/ISO3166-1.json', 'utf-8'));

const paises= JSON.parse(fs.readFileSync(__dirname+'/json/paises.json', 'utf-8'));
const dptos= JSON.parse(fs.readFileSync(__dirname+'/json/dptos.json', 'utf-8'));
const mnpos= JSON.parse(fs.readFileSync(__dirname+'/json/mnpo.json', 'utf-8'));
const dptosv= JSON.parse(fs.readFileSync(__dirname+'/json/estadosv.json', 'utf-8'));
const mnposv= JSON.parse(fs.readFileSync(__dirname+'/json/ciudadesv.json', 'utf-8'));
 
const eapb= JSON.parse(fs.readFileSync(__dirname+'/json/eapb.json', 'utf-8'));
const puebloindigena= JSON.parse(fs.readFileSync(__dirname+'/json/puebloindigena.json', 'utf-8'));
const medicamentos= JSON.parse(fs.readFileSync(__dirname+'/json/medicamentos.json', 'utf-8'));

let pacientesServidor=[];
let generalServidor=[];
let enfermeriaServidor=[];
let psicologiaServidor=[];
let nutricionalServidor=[];
let adultoServidor=[];
let menorServidor=[];
let gestanteServidor=[];
 

 

$(function	()	{
	
	console.log(usuario);
	if(usuario.profesion=='1'){var profUser='Médico (a) especialista'}
	if(usuario.profesion=='2'){var profUser='Médico (a) general'}
	if(usuario.profesion=='3'){var profUser='Enfermero (a)'}
	if(usuario.profesion=='4'){var profUser='Auxiliar de enfermería'}
	if(usuario.profesion=='5'){var profUser='Otro'}
	$(".nombre-Usuario").html(usuario.nombres);
	$("#profesion-Usuario").html(profUser);
	$(".user-institucion").html(usuario.institucion);


	$("#userCount").html(pacientes.length);
	$("#orderCount").html(procedimientos.length); 

	var totalatencion=generales.length + enfermeria.length + psicologia.length + nutricional.length + adulto.length + menor.length + gestante.length + procedimientos.length;
	 


	var today = new Date();
	var year = today.getFullYear();

	con1=0;con2=0;con3=0;con4=0;con5=0;con6=0;con7=0;con8=0;con9=0;con10=0;con11=0;con12=0;
	consultasanoactual['general']=0;consultasanoactual['enfermeria']=0;consultasanoactual['psicologia']=0;consultasanoactual['nutricional']=0;consultasanoactual['adulto']=0;consultasanoactual['menor']=0;consultasanoactual['gestante']=0;
	cosnsultaspendientecargar['general']=[];cosnsultaspendientecargar['enfermeria']=[];cosnsultaspendientecargar['psicologia']=[];cosnsultaspendientecargar['nutricional']=[];cosnsultaspendientecargar['adulto']=[];cosnsultaspendientecargar['menor']=[];cosnsultaspendientecargar['gestante']=[];

	for(var i=0;i<pacientes.length;i++){
		if(pacientes[i].estado==0){
			pacientesSinCargar.push(pacientes[i]);
		}
	}
	for(var i=0;i<generales.length;i++){
		if(generales[i].estado==0){cosnsultaspendientecargar['general'].push(generales[i]);}
		var fec=generales[i].fechaConsulta.split("-"); 
		console.log(fec);
		if(fec[2]==year){
			consultasanoactual['general']=consultasanoactual['general']+1;
			if(fec[1]=='01'){con1=con1+1;}
			if(fec[1]=='02'){con2=con2+1;}
			if(fec[1]=='03'){con3=con3+1;}
			if(fec[1]=='04'){con4=con4+1;}
			if(fec[1]=='05'){con5=con5+1;}
			if(fec[1]=='06'){con6=con6+1;}
			if(fec[1]=='07'){con7=con7+1;}
			if(fec[1]=='08'){con8=con8+1;}
			if(fec[1]=='09'){con9=con9+1;}
			if(fec[1]=='10'){con10=con10+1;}
			if(fec[1]=='11'){con11=con11+1;}
			if(fec[1]=='12'){con12=con12+1;}
			
		}

	}
	
	for(var i=0;i<enfermeria.length;i++){
		if(enfermeria[i].estado==0){cosnsultaspendientecargar['enfermeria'].push(enfermeria[i]);}
		var fec=enfermeria[i].fechaConsulta.split("-"); 

		if(fec[2]==year){
			consultasanoactual['enfermeria']=consultasanoactual['enfermeria']+1;
			if(fec[1]=='01'){con1=con1+1;}
			if(fec[1]=='02'){con2=con2+1;}
			if(fec[1]=='03'){con3=con3+1;}
			if(fec[1]=='04'){con4=con4+1;}
			if(fec[1]=='05'){con5=con5+1;}
			if(fec[1]=='06'){con6=con6+1;}
			if(fec[1]=='07'){con7=con7+1;}
			if(fec[1]=='08'){con8=con8+1;}
			if(fec[1]=='09'){con9=con9+1;}
			if(fec[1]=='10'){con10=con10+1;}
			if(fec[1]=='11'){con11=con11+1;}
			if(fec[1]=='12'){con12=con12+1;}
			
		}

	}
	for(var i=0;i<psicologia.length;i++){
		 
		if(psicologia[i].estado==0){cosnsultaspendientecargar['psicologia'].push(psicologia[i]);}
		var fec=psicologia[i].fechaConsulta.split("-"); 

		if(fec[2]==year){
			consultasanoactual['psicologia']=consultasanoactual['psicologia']+1;
			if(fec[1]=='01'){con1=con1+1;}
			if(fec[1]=='02'){con2=con2+1;}
			if(fec[1]=='03'){con3=con3+1;}
			if(fec[1]=='04'){con4=con4+1;}
			if(fec[1]=='05'){con5=con5+1;}
			if(fec[1]=='06'){con6=con6+1;}
			if(fec[1]=='07'){con7=con7+1;}
			if(fec[1]=='08'){con8=con8+1;}
			if(fec[1]=='09'){con9=con9+1;}
			if(fec[1]=='10'){con10=con10+1;}
			if(fec[1]=='11'){con11=con11+1;}
			if(fec[1]=='12'){con12=con12+1;}
			
		}

	}
	for(var i=0;i<nutricional.length;i++){
		 
		if(nutricional[i].estado==0){cosnsultaspendientecargar['nutricional'].push(nutricional[i]);}
		var fec=nutricional[i].fechaConsulta.split("-"); 

		if(fec[2]==year){
			consultasanoactual['nutricional']=consultasanoactual['nutricional']+1;
			if(fec[1]=='01'){con1=con1+1;}
			if(fec[1]=='02'){con2=con2+1;}
			if(fec[1]=='03'){con3=con3+1;}
			if(fec[1]=='04'){con4=con4+1;}
			if(fec[1]=='05'){con5=con5+1;}
			if(fec[1]=='06'){con6=con6+1;}
			if(fec[1]=='07'){con7=con7+1;}
			if(fec[1]=='08'){con8=con8+1;}
			if(fec[1]=='09'){con9=con9+1;}
			if(fec[1]=='10'){con10=con10+1;}
			if(fec[1]=='11'){con11=con11+1;}
			if(fec[1]=='12'){con12=con12+1;}
			
		}

	}
	for(var i=0;i<adulto.length;i++){
		 
		if(adulto[i].estado==0){cosnsultaspendientecargar['adulto'].push(adulto[i]);}
		var fec=adulto[i].fechaConsulta.split("-"); 

		if(fec[2]==year){
			consultasanoactual['adulto']=consultasanoactual['adulto']+1;
			if(fec[1]=='01'){con1=con1+1;}
			if(fec[1]=='02'){con2=con2+1;}
			if(fec[1]=='03'){con3=con3+1;}
			if(fec[1]=='04'){con4=con4+1;}
			if(fec[1]=='05'){con5=con5+1;}
			if(fec[1]=='06'){con6=con6+1;}
			if(fec[1]=='07'){con7=con7+1;}
			if(fec[1]=='08'){con8=con8+1;}
			if(fec[1]=='09'){con9=con9+1;}
			if(fec[1]=='10'){con10=con10+1;}
			if(fec[1]=='11'){con11=con11+1;}
			if(fec[1]=='12'){con12=con12+1;}
			
		}

	}
	for(var i=0;i<menor.length;i++){
		 
		if(menor[i].estado==0){cosnsultaspendientecargar['menor'].push(menor[i]);}
		var fec=menor[i].fechaConsulta.split("-"); 

		if(fec[2]==year){
			consultasanoactual['menor']=consultasanoactual['menor']+1;
			if(fec[1]=='01'){con1=con1+1;}
			if(fec[1]=='02'){con2=con2+1;}
			if(fec[1]=='03'){con3=con3+1;}
			if(fec[1]=='04'){con4=con4+1;}
			if(fec[1]=='05'){con5=con5+1;}
			if(fec[1]=='06'){con6=con6+1;}
			if(fec[1]=='07'){con7=con7+1;}
			if(fec[1]=='08'){con8=con8+1;}
			if(fec[1]=='09'){con9=con9+1;}
			if(fec[1]=='10'){con10=con10+1;}
			if(fec[1]=='11'){con11=con11+1;}
			if(fec[1]=='12'){con12=con12+1;}
			
		}

	}
	for(var i=0;i<gestante.length;i++){
		if(gestante[i].estado==0){cosnsultaspendientecargar['gestante'].push(gestante[i]);}
		console.log(gestante[i].fechaConsulta);
		if(gestante[i].fechaConsulta!=undefined){
			var fec=gestante[i].fechaConsulta.split("-"); 

			if(fec[2]==year){
				consultasanoactual['gestante']=consultasanoactual['gestante']+1;
				if(fec[1]=='01'){con1=con1+1;}
				if(fec[1]=='02'){con2=con2+1;}
				if(fec[1]=='03'){con3=con3+1;}
				if(fec[1]=='04'){con4=con4+1;}
				if(fec[1]=='05'){con5=con5+1;}
				if(fec[1]=='06'){con6=con6+1;}
				if(fec[1]=='07'){con7=con7+1;}
				if(fec[1]=='08'){con8=con8+1;}
				if(fec[1]=='09'){con9=con9+1;}
				if(fec[1]=='10'){con10=con10+1;}
				if(fec[1]=='11'){con11=con11+1;}
				if(fec[1]=='12'){con12=con12+1;}
				
			}
		}
		

	}
	console.log(procedimientos);
	cosnsultaspendientecargar['procedimientos']=[];
	for(var i=0;i<procedimientos.length;i++){
		if(procedimientos[i].estado==0){
			console.log(procedimientos[i]);
			cosnsultaspendientecargar['procedimientos'].push(procedimientos[i]);
		}
		 
		

	}
	var totalConsul=generales.length+enfermeria.length+psicologia.length+nutricional.length+adulto.length+menor.length+gestante.length;
	$("#serverloadCount").html(totalConsul);
	$("#serverloadCount2").html(totalConsul);
	  
	var cont='';
	var contPac='';
	var contPro='';
	var contlop=1;
	var contlopro=1;
	for(var t=0;t<pacientesSinCargar.length;t++){
		contPac+='<tr>'
				+'<td>'+(t+1)+'</td>' 
				+'<td>'+pacientesSinCargar[t].tipoidRegPac+'</td>' 
				+'<td>'+pacientesSinCargar[t].idRegPac+'</td>' 
				+'<td>'+pacientesSinCargar[t].nombres+' '+pacientesSinCargar[t].papellido+' '+pacientesSinCargar[t].sapellido+'</td>' 
				+'<td><span class="badge badge-info">'+pacientesSinCargar[t].fecha_registro+'</span></td>' 
			+'</tr>';
	}
	for(var t=0;t<cosnsultaspendientecargar['general'].length;t++){
		$(".btnupload").removeClass('disabled');
		cont+='<tr>'
			+'<td>'+(contlop++)+'</td>'
			+'<td><strong>General</strong></td>'
			+'<td>'+cosnsultaspendientecargar['general'][t].tipoid_pac+'</td>' 
			+'<td>'+cosnsultaspendientecargar['general'][t].numid_pac+'</td>'  
			+'<td><span class="badge badge-info">'+cosnsultaspendientecargar['general'][t].fechaConsulta+'</span></td>' 
			+'</tr>';
	}
	for(var t=0;t<cosnsultaspendientecargar['enfermeria'].length;t++){
		
		$(".btnupload").removeClass('disabled');
		cont+='<tr>'
			+'<td>'+(contlop++)+'</td>'
			+'<td><strong>Enfermeria</strong></td>'
			+'<td>'+cosnsultaspendientecargar['enfermeria'][t].tipoid_pac+'</td>' 
			+'<td>'+cosnsultaspendientecargar['enfermeria'][t].numid_pac+'</td>'  
			+'<td><span class="badge badge-info">'+cosnsultaspendientecargar['enfermeria'][t].fechaConsulta+'</span></td>' 
			+'</tr>';
	}
	for(var t=0;t<cosnsultaspendientecargar['psicologia'].length;t++){
	 	$(".btnupload").removeClass('disabled');
		cont+='<tr>'
			+'<td>'+(contlop++)+'</td>'
			+'<td><strong>Psicologia</strong></td>'
			+'<td>'+cosnsultaspendientecargar['psicologia'][t].tipoid_pac+'</td>' 
			+'<td>'+cosnsultaspendientecargar['psicologia'][t].numid_pac+'</td>'  
			+'<td><span class="badge badge-info">'+cosnsultaspendientecargar['psicologia'][t].fechaConsulta+'</span></td>' 
			+'</tr>';
	}
	for(var t=0;t<cosnsultaspendientecargar['nutricional'].length;t++){
		
		$(".btnupload").removeClass('disabled');
		cont+='<tr>'
			+'<td>'+(contlop++)+'</td>'
			+'<td><strong>Nutricional</strong></td>'
			+'<td>'+cosnsultaspendientecargar['nutricional'][t].tipoid_pac+'</td>' 
			+'<td>'+cosnsultaspendientecargar['nutricional'][t].numid_pac+'</td>'  
			+'<td><span class="badge badge-info">'+cosnsultaspendientecargar['nutricional'][t].fechaConsulta+'</span></td>' 
			+'</tr>';
	}
	for(var t=0;t<cosnsultaspendientecargar['adulto'].length;t++){
		
		$(".btnupload").removeClass('disabled');
		cont+='<tr>'
			+'<td>'+(contlop++)+'</td>'
			+'<td><strong>Adulto</strong></td>'
			+'<td>'+cosnsultaspendientecargar['adulto'][t].tipoid_pac+'</td>' 
			+'<td>'+cosnsultaspendientecargar['adulto'][t].numid_pac+'</td>'  
			+'<td><span class="badge badge-info">'+cosnsultaspendientecargar['adulto'][t].fechaConsulta+'</span></td>' 
			+'</tr>';
	}
	for(var t=0;t<cosnsultaspendientecargar['menor'].length;t++){
		
		$(".btnupload").removeClass('disabled');
		cont+='<tr>'
			+'<td>'+(contlop++)+'</td>'
			+'<td><strong>Menor</strong></td>'
			+'<td>'+cosnsultaspendientecargar['menor'][t].tipoid_pac+'</td>' 
			+'<td>'+cosnsultaspendientecargar['menor'][t].numid_pac+'</td>'  
			+'<td><span class="badge badge-info">'+cosnsultaspendientecargar['menor'][t].fechaConsulta+'</span></td>' 
			+'</tr>';
	}
	for(var t=0;t<cosnsultaspendientecargar['gestante'].length;t++){
		
		$(".btnupload").removeClass('disabled');
		cont+='<tr>'
			+'<td>'+(contlop++)+'</td>'
			+'<td><strong>Gestante</strong></td>'
			+'<td>'+cosnsultaspendientecargar['gestante'][t].tipoid_pac+'</td>' 
			+'<td>'+cosnsultaspendientecargar['gestante'][t].numid_pac+'</td>'  
			+'<td><span class="badge badge-info">'+cosnsultaspendientecargar['gestante'][t].fechaConsulta+'</span></td>' 
			+'</tr>';
	}
	 
	for(var t=0;t<cosnsultaspendientecargar['procedimientos'].length;t++){
		
		$(".btnuploadProc").removeClass('disabled');
		contPro+='<tr>'
			+'<td>'+(contlopro++)+'</td>' 
			+'<td>'+cosnsultaspendientecargar['procedimientos'][t].tipodocupacie+'</td>' 
			+'<td>'+cosnsultaspendientecargar['procedimientos'][t].numDocpPaci+'</td>'  
			+'<td><span class="badge badge-info">'+cosnsultaspendientecargar['procedimientos'][t].fechaProce+'</span></td>' 
			+'</tr>';
	}
	 
	(cont=='')?$("#tableUpload").html('<tr><td colspan="5">No hay datos pendientes</td></tr>'):$("#tableUpload").html(cont);
	(contPro=='')?$("#tableUploadProc").html('<tr><td colspan="5">No hay datos pendientes</td></tr>'):$("#tableUploadProc").html(contPro);
	(contPac=='')?$("#tableUploadPac").html('<tr><td colspan="5">No hay datos pendientes</td></tr>'):$("#tableUploadPac").html(contPac);
	//$("#tableUpload").html(cont);
	//$("#tableUploadPac").html(contPac);
	if(pacientesSinCargar.length!=0){
		$(".btnupload").addClass('disabled');
		$(".btnuploadPac").removeClass('disabled');
		$(".btnuploadProc").addClass('disabled');
	} 
	//Flot Chart
	//Website traffic chart				
	var init = { data: [ [1, con1], [2, con2], [3, con3], [4, con4], [5,con5], [6, con6], [7, con7], [8, con8], [9, con9], [10, con10], [11, con11], [12, con12]],
			 label: "Consultas"
		},
		options = {	
			series: {
				lines: {
					show: true, 
					fill: true,
					fillColor: 'rgba(121,206,167,0.2)'
				},
				points: {
					show: true,
					radius: '4.5'
				}
			},
			grid: {
				hoverable: true,
				clickable: true
			},
			colors: ["#37b494"]
		},
		plot;
			
	plot = $.plot($('#placeholder'), [init], options);
			
	$("<div id='tooltip'></div>").css({
		position: "absolute",
		display: "none",
		border: "1px solid #222",
		padding: "4px",
		color: "#fff",
		"border-radius": "4px",
		"background-color": "rgb(0,0,0)",
		opacity: 0.90
	}).appendTo("body");

	$("#placeholder").bind("plothover", function (event, pos, item) {

		var str = "(" + pos.x.toFixed(2) + ", " + pos.y.toFixed(2) + ")";
		$("#hoverdata").text(str);
	
		if (item) {
			var x = item.datapoint[0],
				y = item.datapoint[1];
				var mes='';
				if(x==1){ mes='Enero'} 
				if(x==2){ mes='Febrero'}
				if(x==3){ mes='Marzo'}
				if(x==4){ mes='Abril'}
				if(x==5){ mes='Mayo'}
				if(x==6){ mes='Junio'}
				if(x==7){ mes='Julio'}
				if(x==8){ mes='Agosto'}
				if(x==9){ mes='Septiembre'}
				if(x==10){ mes='Octubre'}
				if(x==11){ mes='Noviembre'}
				if(x==12){ mes='Diciembre'} 
				$("#tooltip").html("Consultas "+ mes +": " + y)
				.css({top: item.pageY+5, left: item.pageX+5})
				.fadeIn(200);
		} else {
			$("#tooltip").hide();
		}
	});

	$("#placeholder").bind("plotclick", function (event, pos, item) {
		if (item) {
			$("#clickdata").text(" - click point " + item.dataIndex + " in " + item.series.label);
			plot.highlight(item.series, item.datapoint);
		}
	});
			
	var animate = function () {
	   $('#placeholder').animate( {tabIndex: 0}, {
		   duration: 3000,
		   step: function ( now, fx ) {

				 var r = $.map( init.data, function ( o ) {
					  return [[ o[0], o[1] * fx.pos ]];
				});

				 plot.setData( [{ data: r }] );
			 plot.draw();
			}	
		});
	}
		
	animate();
 
	var barChart = Morris.Bar({
	  element: 'barChart',
	  data: [
		{ y: 'General', a: consultasanoactual['general']},
		{ y: 'Enfermeria', a: consultasanoactual['enfermeria'] },
		{ y: 'Psicologia', a: consultasanoactual['psicologia'] },
		{ y: 'Nutricional', a: consultasanoactual['nutricional'] },
		{ y: 'Adulto', a: consultasanoactual['adulto'] },
		{ y: 'Menor', a: consultasanoactual['menor']},
		{ y: 'Gestante', a: consultasanoactual['gestante']}
	  ],
	  xkey: 'y',
	  ykeys: 'a',
	  grid: true,
	  labels: ['Consultas'],
	  barColors: ['#6BAFBD'],
	  gridTextColor : '#fff'
	});

	//Sparkline
	 
	//Timeline color box
	$('.timeline-img').colorbox({
		rel:'group1',
		width:"90%",
		maxWidth:'800px'
	});

	//Resize graph when toggle side menu
	$('.navbar-toggle').click(function()	{
		setTimeout(function() {
			//donutChart.redraw();
			//lineChart.redraw();
			barChart.redraw();			
			
			$.plot($('#placeholder'), [init], options);
		},500);	
	});
	
	$('.size-toggle').click(function()	{
		//resize morris chart
		setTimeout(function() {
			//uudonutChart.redraw();
			//lineChart.redraw();
			barChart.redraw();	

			$.plot($('#placeholder'), [init], options);			
		},500);
	});

	//Refresh statistic widget
	$('.refresh-button').click(function() {
		var _overlayDiv = $(this).parent().children('.loading-overlay');
		_overlayDiv.addClass('active');
		
		setTimeout(function() {
			_overlayDiv.removeClass('active');
		}, 2000);
		
		return false;
	});
	
	$(window).resize(function(e)	{
		
		//Sparkline
		$('#visits').sparkline([15,19,20,22,33,27,31,27,19,30,21,10,15,18,25,9], {
			type: 'bar', 
			barColor: '#fa4c38',	
			height:'35px',
			weight:'96px'
		});
		$('#balances').sparkline([220,160,189,156,201,220,104,242,221,111,164,242,183,165], {
			type: 'bar', 
			barColor: '#92cf5c',	
			height:'35px',
			weight:'96px'
		});

		//resize morris chart
		setTimeout(function() {
			//donutChart.redraw();
			//lineChart.redraw();
			barChart.redraw();			
			
			$.plot($('#placeholder'), [init], options);
		},500);
	});
	
	$(window).load(function(e)	{
	
		//Number Animation
		 
		var currentBalance = $('#currentBalance').text();
		
		$({numberValue: 0}).animate({numberValue: currentBalance}, {
			duration: 2500,
			easing: 'linear',
			step: function() { 
				$('#currentBalance').text(totalatencion); 
			}
		});
			
		setInterval(function() {
			var currentNumber = $('#visitorCount').text();
			var randomNumber = Math.floor(Math.random()*50) + 1;
			var newNumber = parseInt(currentNumber, 10) + parseInt(randomNumber, 10); 
		
			$({numberValue: currentNumber}).animate({numberValue: newNumber}, {
				duration: 500,
				easing: 'linear',
				step: function() { 
					$('#visitorCount').text(Math.ceil(this.numberValue)); 
				}
			});
		}, 5000);
	});
	var contPaises='<option></option>';
	for(var t=0;t<paises.length;t++){
		contPaises+='<option value="'+paises[t].Id+'">'+paises[t].nombre+'</option>';
	}

	var condptor='<option></option>';
	for(var ty=0;ty<dptos.length;ty++){
		condptor+='<option value="'+dptos[ty].Id+'">'+dptos[ty].nombre+'</option>';
	}
	$("#AgendardptoResidencia").html(condptor);

	$("#dptoResidencia").html(condptor);

	$("#AgendarpaisProcedencia").html(contPaises);
	$("#paisProcedencia").html(contPaises);

	var conteapb='<option></option>';
	for(var ty=0;ty<eapb.length;ty++){
		conteapb+='<option value="'+eapb[ty].Id+'">'+eapb[ty].nombre+'</option>';
	}
	$("#Agendareapb").html(conteapb);
	$("#eapb").html(conteapb);

	var contpuebloindigena='<option value="NA" selected>NA</option>';
	for(var ty=0;ty<puebloindigena.length;ty++){
		contpuebloindigena+='<option value="'+puebloindigena[ty].Id+'">'+puebloindigena[ty].nombre+'</option>';
	}
	$("#AgendarpueIndigena").html(contpuebloindigena);
	$("#pueIndigena").html(contpuebloindigena);

	$("#AgendarPaisResidencia").val(45);
	$("#PaisResidencia").val(45);
	listarMedicamentos();
});
//'key':'GimmidsApp'
//------------CARGUE DATOS AL SERVIDOR
function cargarPacientesServer(){
	console.log(pacientes);
	for(var t3=0;t3<pacientes.length;t3++){
		if(pacientes[t3].estado==0){
	
			$.ajax({
				url: "https://api.gimmids.com/pruebas/servicios/registrarPaciente.php",
				type: "post",
				dataType: "html",
				data: {"datos":  pacientes[t3], 'key':'GimmidsApp' },
				async:false
			}).done(function(res){
				console.log(res);
				try {
					var data=JSON.parse(res); 
					console.log(data);
					if (data.STATUS == 'OK') { 
						console.log('revisando');
						//asignamos el id registrado y cambiamos el estado a 1 
						pacientes[t3].id = data.ID;
						pacientes[t3].estado=1; 
						//procedemos a buscar las consultas qeu contengan el idjson del paciente para actualizarl el id del paciente
						CambioIDconsultas(pacientes[t3].idJSON, pacientes[t3].id );
					 
						fs.writeFileSync(__dirname+'/json/pacientes.json', JSON.stringify(pacientes));
					}
				} catch (error) {
					
				} 
					
			} ).fail(function(e) { 
				console.log(e);
				 alert('Error'+ e);
				
			});
	
	
		}
	}
	alert('Pacientes Cargados con Exito!..')
	window.location.reload();
}
function CambioIDconsultas(idjson,nuevo){

	for(var s5=0;s5<generales.length;s5++){
		if(generales[s5].idJSON_paciente==idjson){
			
			generales[s5].id_paciente=nuevo;
	 
		}
	} 
	fs.writeFileSync(__dirname+'/json/consultas_generales.json', JSON.stringify(generales));
	
	for(var s5=0;s5<enfermeria.length;s5++){
		if(enfermeria[s5].idJSON_paciente==idjson){
			
			enfermeria[s5].id_paciente=nuevo;
	
	
		}
	} 
	fs.writeFileSync(__dirname+'/json/consultas_enfermeria.json', JSON.stringify(enfermeria));
	
	for(var s5=0;s5<psicologia.length;s5++){
		if(psicologia[s5].idJSON_paciente==idjson){
			
			psicologia[s5].id_paciente=nuevo;
	
	
		}
	} 
	fs.writeFileSync(__dirname+'/json/consultas_psicologia.json', JSON.stringify(psicologia));
	
	for(var s5=0;s5<nutricional.length;s5++){
		if(nutricional[s5].idJSON_paciente==idjson){
			
			nutricional[s5].id_paciente=nuevo;
	
	
		}
	} 
	fs.writeFileSync(__dirname+'/json/consultas_nutricional.json', JSON.stringify(nutricional));
	
	for(var s5=0;s5<adulto.length;s5++){
		if(adulto[s5].idJSON_paciente==idjson){
			
			adulto[s5].id_paciente=nuevo;
	
	
		}
	} 
	fs.writeFileSync(__dirname+'/json/consultas_adulto.json', JSON.stringify(adulto));
	
	for(var s5=0;s5<menor.length;s5++){
		if(menor[s5].idJSON_paciente==idjson){
			
			menor[s5].id_paciente=nuevo;
	
	
		}
	} 
	fs.writeFileSync(__dirname+'/json/consultas_menor.json', JSON.stringify(menor));
	
	for(var s5=0;s5<gestante.length;s5++){
		if(gestante[s5].idJSON_paciente==idjson){
			
			gestante[s5].id_paciente=nuevo;
	
	
		}
	} 
	fs.writeFileSync(__dirname+'/json/consultas_gestaciones.json', JSON.stringify(gestante));
	
	
        
}
function cargarConsultasServer(){
	console.log('cargando consultas al servidor');
	for(var s1=0;s1<generales.length;s1++){
		if(generales[s1].estado==0){
			//si el estado es 0 realizamos el ajax para subir al servidor  asyncorinco false     
			
			varDataIn={
				'id_paciente': generales[s1].id_paciente,
				'idJSON_paciente': generales[s1].idJSON_paciente,
				'numid_pac': generales[s1].numid_pac,
				'tipoid_pac': generales[s1].tipoid_pac,
				'institucion': usuario.institucion,
				'data':JSON.stringify(generales[s1]),
				'key':'GimmidsApp'
			};
			
			$.ajax({
				url: "https://api.gimmids.com/pruebas/servicios/registerGeneralConsultation.php",
				type: "post",
				dataType: "html",
				data: {"datos":  varDataIn},
				async:false
			}).done(function(res){
				 console.log(res);
				var data=JSON.parse(res); 
				 
				if (data.STATUS == 'OK') {
					//asignamos el id registrado y cambiamos el estado a 1 
					generales[s1].id_consulta = data.ID;
					generales[s1].estado=1;
					
					fs.writeFileSync(__dirname+'/json/consultas_generales.json', JSON.stringify(generales));
					   
				} 
			} );
		} 
	} 
	for(var s1=0;s1<enfermeria.length;s1++){
		if(enfermeria[s1].estado==0){
			//si el estado es 0 realizamos el ajax para subir al servidor  asyncorinco false     
			varDataIn={
				'id_paciente': enfermeria[s1].id_paciente,
				'idJSON_paciente': enfermeria[s1].idJSON_paciente,
				'numid_pac': enfermeria[s1].numid_pac,
				'tipoid_pac': enfermeria[s1].tipoid_pac,
				'institucion': usuario.institucion,
				'data':JSON.stringify(enfermeria[s1]),
				'key':'GimmidsApp'
			};
			$.ajax({
				url: "https://api.gimmids.com/pruebas/servicios/registerNurseConsultation.php",
				type: "post",
				dataType: "html",
				data: {"datos": varDataIn},
				async:false
			}).done(function(res){
				 
				var data=JSON.parse(res); 
				 
				if (data.STATUS == 'OK') {
					//asignamos el id registrado y cambiamos el estado a 1 
					enfermeria[s1].id_consulta = data.ID;
					enfermeria[s1].estado=1;
					
					fs.writeFileSync(__dirname+'/json/consultas_enfermeria.json', JSON.stringify(enfermeria));
					   
				} 
			} );
		} 
	} 
	for(var s1=0;s1<psicologia.length;s1++){
		if(psicologia[s1].estado==0){
			//si el estado es 0 realizamos el ajax para subir al servidor  asyncorinco false     
			varDataIn={
				'id_paciente': psicologia[s1].id_paciente,
				'idJSON_paciente': psicologia[s1].idJSON_paciente,
				'numid_pac': psicologia[s1].numid_pac,
				'tipoid_pac': psicologia[s1].tipoid_pac,
				'institucion': usuario.institucion,
				'data':JSON.stringify(psicologia[s1]),
				'key':'GimmidsApp'
			};
			$.ajax({
				url: "https://api.gimmids.com/pruebas/servicios/registerPsicoConsultation.php",
				type: "post",
				dataType: "html",
				data: {"datos":  varDataIn},
				async:false
			}).done(function(res){
				 
				var data=JSON.parse(res); 
				 
				if (data.STATUS == 'OK') {
					//asignamos el id registrado y cambiamos el estado a 1 
					psicologia[s1].id_consulta = data.ID;
					psicologia[s1].estado=1;
					
					fs.writeFileSync(__dirname+'/json/consultas_psicologia.json', JSON.stringify(psicologia));
					   
				} 
			} );
		} 
	} 
	for(var s1=0;s1<nutricional.length;s1++){
		if(nutricional[s1].estado==0){
			//si el estado es 0 realizamos el ajax para subir al servidor  asyncorinco false     
			varDataIn={
				'id_paciente': nutricional[s1].id_paciente,
				'idJSON_paciente': nutricional[s1].idJSON_paciente,
				'numid_pac': nutricional[s1].numid_pac,
				'tipoid_pac': nutricional[s1].tipoid_pac,
				'institucion': usuario.institucion,
				'data':JSON.stringify(nutricional[s1]),
				'key':'GimmidsApp'
			};
			$.ajax({
				url: "https://api.gimmids.com/pruebas/servicios/registerNutriConsultation.php",
				type: "post",
				dataType: "html",
				data: {"datos": varDataIn},
				async:false
			}).done(function(res){
				 console.log(res);
				var data=JSON.parse(res); 
				 
				if (data.STATUS == 'OK') {
					//asignamos el id registrado y cambiamos el estado a 1 
					nutricional[s1].id_consulta = data.ID;
					nutricional[s1].estado=1;
					
					fs.writeFileSync(__dirname+'/json/consultas_nutricional.json', JSON.stringify(nutricional));
					   
				} 
			} );
		} 
	} 
	for(var s1=0;s1<adulto.length;s1++){
		if(adulto[s1].estado==0){
			//si el estado es 0 realizamos el ajax para subir al servidor  asyncorinco false     
			varDataIn={
				'id_paciente': adulto[s1].id_paciente,
				'idJSON_paciente': adulto[s1].idJSON_paciente,
				'numid_pac': adulto[s1].numid_pac,
				'tipoid_pac': adulto[s1].tipoid_pac,
				'institucion': usuario.institucion,
				'data':JSON.stringify(adulto[s1]),
				'key':'GimmidsApp'
			};
			$.ajax({
				url: "https://api.gimmids.com/pruebas/servicios/registerAdultConsultation.php",
				type: "post",
				dataType: "html",
				data: {"datos":  varDataIn },
				async:false
			}).done(function(res){
				 
				var data=JSON.parse(res); 
				 
				if (data.STATUS == 'OK') {
					//asignamos el id registrado y cambiamos el estado a 1 
					adulto[s1].id_consulta = data.ID;
					adulto[s1].estado=1;
					
					fs.writeFileSync(__dirname+'/json/consultas_adulto.json', JSON.stringify(adulto));
					   
				} 
			} );
		} 
	} 
	for(var s1=0;s1<menor.length;s1++){
		if(menor[s1].estado==0){
			//si el estado es 0 realizamos el ajax para subir al servidor  asyncorinco false     
			varDataIn={
				'id_paciente': menor[s1].id_paciente,
				'idJSON_paciente': menor[s1].idJSON_paciente,
				'numid_pac': menor[s1].numid_pac,
				'tipoid_pac': menor[s1].tipoid_pac,
				'institucion': usuario.institucion,
				'data':JSON.stringify(menor[s1]),
				'key':'GimmidsApp'
			};
			$.ajax({
				url: "https://api.gimmids.com/pruebas/servicios/registerMenorConsultation.php",
				type: "post",
				dataType: "html",
				data: {"datos":  varDataIn},
				async:false
			}).done(function(res){
				 
				var data=JSON.parse(res); 
				 
				if (data.STATUS == 'OK') {
					//asignamos el id registrado y cambiamos el estado a 1 
					menor[s1].id_consulta = data.ID;
					menor[s1].estado=1;
					
					fs.writeFileSync(__dirname+'/json/consultas_menor.json', JSON.stringify(menor));
					   
				} 
			} );
		} 
	} 
	for(var s1=0;s1<gestante.length;s1++){
		if(gestante[s1].estado==0){
			//si el estado es 0 realizamos el ajax para subir al servidor  asyncorinco false     
			varDataIn={
				'id_paciente': gestante[s1].id_paciente,
				'idJSON_paciente': gestante[s1].idJSON_paciente,
				'numid_pac': gestante[s1].numid_pac,
				'tipoid_pac': gestante[s1].tipoid_pac,
				'institucion': usuario.institucion,
				'data':JSON.stringify(gestante[s1]),
				'key':'GimmidsApp'
			};
			$.ajax({
				url: "https://api.gimmids.com/pruebas/servicios/registerPregnantConsultation.php",
				type: "post",
				dataType: "html",
				data: {"datos": gestante[s1],'key':'GimmidsApp'},
				async:false
			}).done(function(res){
				 console.log(res)
				var data=JSON.parse(res); 
				 
				if (data.STATUS == 'OK') {
					//asignamos el id registrado y cambiamos el estado a 1 
					gestante[s1].id_consulta = data.ID;
					gestante[s1].estado=1;
					
					fs.writeFileSync(__dirname+'/json/consultas_gestaciones.json', JSON.stringify(gestante));
					   
				} 
			} );
		} 
	} 
	alert('Consultas cargadas al servidor');
	window.location.reload();
}
 function cargarProcedimientosServer(){
	 for(var a=0; a<procedimientos.length;a++){
		if(parseInt(procedimientos[a].estado)==0){
			var varDataIn={
				'numid_pac': procedimientos[a].numDocpPaci,
				 'tipoid_pac': procedimientos[a].tipodocupacie,
				 'institucion': usuario.institucion,
				 'data':JSON.stringify(procedimientos[a]),
				 'key':'GimmidsApp'
			 };
			 console.log(varDataIn);
			 $.ajax({
				 url: "https://api.gimmids.com/pruebas/servicios/registrarProcedimiento.php",
				 type: "post",
				 data: {'datos': varDataIn},
				 async:false
			 }).done(function(res){
				 console.log(res);
				 console.log("Respuesta: "); 
				 try {
					 var data=JSON.parse(res);
					 console.log(data);  
					 if (data.STATUS == 'OK') {
						procedimientos[a].id_consulta = data.ID;
						procedimientos[a].estado = 1;
						  
						 fs.writeFileSync(__dirname+'/json/procedimientos.json', JSON.stringify(procedimientos));
					 
					 } else {
						 console.log(data);  
						 console.log(data.ERROR);
					  
					 }
				 } catch (error) {
					 console.log(error);
				 }
			 } ).fail(function(r) { 
				  console.logr(r);
			 });
		}
		
	 }
	 alert('Se ha cargado la información al servidor!...');
	 location.reload();
 }

//------------BUSQUEDA PACIENTE ADMISION
function continuarRegistroAdmision(){
	var valven = 1;
	if ($("#AgendaridRegPac").val() && $("#AgendartipoidRegPac").val()) {
		
		console.log('buscar paciente por admision');
		if ($("#AgendartipoidRegPac").val() == 'AS' || $("#AgendartipoidRegPac").val() == 'MS') {
			var as = $("#AgendaridRegPac").val();
			valven =validarISO(as[0] + as[1] + as[2]);
		}
		
		if (valven == 1) {
			var resultadoPacie = buscarPaciente($("#AgendartipoidRegPac").val(), $("#AgendaridRegPac").val());
			console.log(resultadoPacie);
			if (resultadoPacie == "LIBRE") {
				validacionCedula = 1;
				
				if (confirm('Paciente no encontrado. Desea Buscar el paciente remotamente?.')) {
					var dataIn = { 'cc': $("#AgendartipoidRegPac").val(), 'id': $("#AgendaridRegPac").val(),'key':'GimmidsApp'  };
					console.log(dataIn);
					$.post('https://api.gimmids.com/pruebas/servicios/buscarPaciente.php', dataIn, function(data) {
						console.log(data);
						if (data.STATUS == 'OK') {
							if (data.DATA.length > 0) {
								 			
								pacientes.push(data.DATA[data.DATA.length - 1])
								fs.writeFileSync(__dirname+'/json/pacientes.json', JSON.stringify(pacientes));
								$("#admisionar-modal").modal('hide');

								$("#AgendarID").val(data.DATA[data.DATA.length - 1].id);
								$("#AgendarIDJSON").val(data.DATA[data.DATA.length - 1].idJSON);
								$("#AgendartipoidRegPacAdmision").val(data.DATA[data.DATA.length - 1].tipoidRegPac);
								$("#AgendaridRegPacAdmision").val(data.DATA[data.DATA.length - 1].idRegPac);
								$("#AgendarotroDocumRepAdmision").val(data.DATA[data.DATA.length - 1].otroDocumRep);
								$("#AgendarSexo").val(data.DATA[data.DATA.length - 1].sexo);
								$("#AgendarNombresAdmision").val(data.DATA[data.DATA.length - 1].nombres + ' ' + data.DATA[data.DATA.length - 1].papellido + ' ' + data.DATA[data.DATA.length - 1].sapellido);
								$("#AgendartipoidRegPac").val(null);
								$("#AgendaridRegPac").val(null);
								$("#AgendarotroDocumRep").val(null);
								
								$.post('https://api.gimmids.com/pruebas/servicios/listarUsuarios.php',{'institucion':usuario.institucion,'key':'GimmidsApp' }, function(dataprof){
									console.log(dataprof);
									if(dataprof.STATUS="OK"){
										var contprof='<option></option>';
										for(var tyu=0;tyu<dataprof.DATA.length;tyu++){
											console.log(dataprof.DATA[tyu]);
											if(dataprof.DATA[tyu].permiso_hamb==1){
												contprof+='<option value="'+dataprof.DATA[tyu].numid+'">'+dataprof.DATA[tyu].nombres+'</option>';
											}
										}
										$("#AgendarpprofeAgendarAdmision").html(contprof);
								
									}else{
										alert('Error al listar profesionales');
									}
								},"JSON").fail(function(e){
									alert('Error en el servidor al listar profesionales');
									
								});
								alert('Paciente encontrado!..');
								//ABRIR VENTANA HIJA
								$("#regAdmision-modal").modal('show');


							} else {
								alert("Paciente no encontrado!...");
								$("#contAdmisionarPaciente").removeClass('hide');
							}

						} else {
							alert("error al conectar con la base de datos");
						}
					}, "JSON").fail(function(data) {
						console.log(data);
						alert(data.responseText);
					}, "JSON");
				}else{
					$("#contAdmisionarPaciente").removeClass('hide');
				}
			}else{
				$("#admisionar-modal").modal('hide');
				$("#admisionar-modal").modal('hide');

				$("#AgendarID").val(resultadoPacie.id);
				$("#AgendarIDJSON").val(resultadoPacie.idJSON);
				$("#AgendartipoidRegPacAdmision").val(resultadoPacie.tipoidRegPac);
				$("#AgendaridRegPacAdmision").val(resultadoPacie.idRegPac);
				$("#AgendarotroDocumRepAdmision").val(resultadoPacie.otroDocumRep);
				$("#AgendarSexo").val(resultadoPacie.sexo);
				$("#AgendarNombresAdmision").val(resultadoPacie.nombres + ' ' + resultadoPacie.papellido + ' ' + resultadoPacie.sapellido);
				$("#AgendartipoidRegPac").val(null);
				$("#AgendaridRegPac").val(null);
				$("#AgendarotroDocumRep").val(null);
				
				$.post('https://api.gimmids.com/pruebas/servicios/listarUsuarios.php',{'institucion':usuario.institucion,'key':'GimmidsApp' }, function(dataprof){
					console.log(dataprof);
					if(dataprof.STATUS="OK"){
						var contprof='<option></option>';
						for(var tyu=0;tyu<dataprof.DATA.length;tyu++){
							console.log(dataprof.DATA[tyu]);
							if(dataprof.DATA[tyu].permiso_hamb==1){
								contprof+='<option value="'+dataprof.DATA[tyu].numid+'">'+dataprof.DATA[tyu].nombres+'</option>';
							}
						}
						$("#AgendarpprofeAgendarAdmision").html(contprof);
				
					}else{
						alert('Error al listar profesionales');
					}
				},"JSON").fail(function(e){
					alert('Error en el servidor al listar profesionales');
					
				});
				alert('Paciente encontrado!..');
				//ABRIR VENTANA HIJA
				$("#regAdmision-modal").modal('show');


				
				 
			}

		}else {
			alert('El documento debe contener la codificion ISO3166-1 de acuerdo a la circular 029!..');
		}

	} else {
		alert('Digite todos los datos para continuar!..');
	}
}
//---REGISTRO DE ADMISION
function registrarAdmision(){
	console.log('registrando');
        var dataIn = {
            'AgendarFechaAgendarAdmision': $("#AgendarFechaAgendarAdmision").val(),
            'AgendarID': $("#AgendarID").val(),
            'AgendarIDJSON': $("#AgendarIDJSON").val(),
            'AgendartipoidRegPacAdmision': $("#AgendartipoidRegPacAdmision").val(),
            'AgendaridRegPacAdmision': $("#AgendaridRegPacAdmision").val(),

        };
        console.log($("#AgendarHoraAgendarAdmision").val() + ':00');

        time1 = $("#AgendarHoraAgendarAdmision").val() + ':00';
        time2 = "00:10:00";
        var SmTimes = formatTime(timestrToSec(time1) - timestrToSec(time2))
        console.log(SmTimes);
        var consuCalenProf = {
            'AgendarpprofeAgendarAdmision':$("#AgendarpprofeAgendarAdmision").val(),
            'AgendarFechaAgendarAdmision': $("#AgendarFechaAgendarAdmision").val(),
            'time1': SmTimes,
            'time2': time1

        };
        $.ajax({
            url: "https://api.gimmids.com/pruebas/servicios/consultarAgendaProfesional.php",
            type: "post",
            dataType: "html",
            data: {"datos":  consuCalenProf,'key':'GimmidsApp'  },
            async:false
        }).done(function(res){
            console.log(res);
            try {
                var data=JSON.parse(res); 
                console.log(data);
                if (data.STATUS == 'OK') { 
                    if (data.DATA[data.DATA.length - 1].cont > 0) {
                        alert('El Profesional no se encuentra disponible!. Agendalo con 10 minutos mas de diferencia.');
                    } else {
                       
                      //procedemos al registro de la admision

						var f = new Date();
						var meses = new Array ("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
							
						var dataIn2 = {
							'AgendarID': $("#AgendarID").val(),
							'AgendarIDJSON': $("#AgendarIDJSON").val(),
							'AgendartipoidRegPacAdmision': $("#AgendartipoidRegPacAdmision").val(),
							'AgendaridRegPacAdmision': $("#AgendaridRegPacAdmision").val(),
							'AgendarotroDocumRepAdmision': $("#AgendarotroDocumRepAdmision").val(),
							'AgendarSexo': $("#AgendarSexo").val(),
							'AgendarNombresAdmision': $("#AgendarNombresAdmision").val(),
							'AgendarpprofeAgendarAdmision': $("#AgendarpprofeAgendarAdmision").val(), //documento del profesional que atiende
							'AgendarServicioAdmision': $("#AgendarServicioAdmision").val(),
							'AgendarFechaAgendarAdmision': $("#AgendarFechaAgendarAdmision").val(),
							'AgendarHoraAgendarAdmision': $("#AgendarHoraAgendarAdmision").val(),
							'usuarioregistraID': usuario.numid,
							'usuarioregistratipoID': usuario.tipoid,
							'fechaReg': f.getDate() + " de " + meses[(f.getMonth() +1)] + " de " + f.getFullYear()
						};
						console.log(dataIn2);
						$.ajax({
							url: "https://api.gimmids.com/pruebas/servicios/agendarServicio.php",
							type: "post",
							dataType: "html",
							data: {"datos":  dataIn2,'key':'GimmidsApp'  },
							async:false
						}).done(function(res){
							console.log(res);
							try {
								var datares=JSON.parse(res);
								if (data.STATUS == 'OK') {  
									alert('Admision agendada Correctamente!..');
									location.reload();
								} else {
									if (confirm('error al registrar Admision. Desea volver a intentarlo?.')) {
										registrarAdmision();
									}
								}
							}catch(error){

							}
						}).fail(function(e){
							alert('error en al conectarse al servidor!..');
							 
						});	
                    }
                }
            } catch (error) {
                
            } 
                
        } ).fail(function(e) { 
            console.log(e);
             alert('Error'+ e);
            
        });
}
//FUNCIONES PARA LA RESTA DE HORAS PAR AVALIDAR LA DISPONIBILIDA DHORARIA DEL PROFESIONAL 
function timestrToSec(timestr) {
    var parts = timestr.split(":");
    return (parts[0] * 3600) +
        (parts[1] * 60) +
        (+parts[2]);
}

function pad(num) {
    if (num < 10) {
        return "0" + num;
    } else {
        return "" + num;
    }
}

function formatTime(seconds) {
    return [pad(Math.floor(seconds / 3600)),
        pad(Math.floor(seconds / 60) % 60),
        pad(seconds % 60),
    ].join(":");
}
//------------BUSQUEDA DE PACIENTE AMBULATORIA
function continuarRegistro(){
	var valven = 1;
	if ($("#idRegPac").val() && $("#tipoidRegPac").val()) {
		
		console.log('buscar paciente por AMBULATORIO');
		if ($("#tipoidRegPac").val() == 'AS' || $("#tipoidRegPac").val() == 'MS') {
			var as = $("#idRegPac").val();
			valven =validarISO(as[0] + as[1] + as[2]);
		}
		
		if (valven == 1) {
			var resultadoPacie = buscarPaciente($("#tipoidRegPac").val(), $("#idRegPac").val());
			console.log(resultadoPacie);
			if (resultadoPacie == "LIBRE") {
				validacionCedula = 1;
				
				if (confirm('Paciente no encontrado. Desea Buscar el paciente remotamente?.')) {
					var dataIn = { 'cc': $("#tipoidRegPac").val(), 'id': $("#idRegPac").val(),'key':'GimmidsApp' };
					console.log(dataIn);
					$.post('https://api.gimmids.com/pruebas/servicios/buscarPaciente.php', dataIn, function(data) {
						console.log(data);
						if (data.STATUS == 'OK') {
							if (data.DATA.length > 0) {
								 			
								pacientes.push(data.DATA[data.DATA.length - 1])
								fs.writeFileSync(__dirname+'/json/pacientes.json', JSON.stringify(pacientes));
								
								localStorage.setItem('paciente', JSON.stringify(data.DATA[data.DATA.length - 1]));
								localStorage.setItem('entrada', 'ambulatorio');
				
								alert('Paciente encontrado!..');
								//ABRIR VENTANA HIJA
								ipc.send('ventana-hija', 'paciente');


							} else {
								alert("Paciente no encontrado!...");
								$("#contPaciente").removeClass('hide');
							}

						} else {
							alert("error al conectar con la base de datos");
						}
					}, "JSON").fail(function(data) {
						console.log(data);
						alert('Error: '+data.responseText);
						$("#contPaciente").removeClass('hide');
					}, "JSON");
				}else{
					$("#contPaciente").removeClass('hide');
				}
			}else{
				localStorage.setItem('paciente', JSON.stringify(resultadoPacie));
				localStorage.setItem('entrada', 'ambulatorio');
				alert('Paciente encontrado!..');
				//ABRIR VENTANA HIJA
				ipc.send('ventana-hija', 'paciente');
			}

		}else {
			alert('El documento debe contener la codificion ISO3166-1 de acuerdo a la circular 029!..');
		}

	} else {
		alert('Digite todos los datos para continuar!..');
	}
}

//-------------------REGISTRO PACIENTES------------------------


function registrarPaciente(tipo){
	console.log('registrando paciente por admiision'); 
	//var user=JSON.parse(localStorage.getItem('user'));
	var f = new Date();
	var meses = new Array ("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
	consecutivoJSONPacientes = obtenerConsecutivoJSONPacientes();

	if(tipo==1){
		regPaciente = {
			'id': 0,
			'idJSON': consecutivoJSONPacientes,
			"tipoidRegPac": $("#AgendartipoidRegPac").val(),
			"idRegPac": $("#AgendaridRegPac").val(),
			"otroDocumRep": ($("#AgendarotroDocumRep").val()) ? $("#AgendarotroDocumRep").val() : '',
			"nombres": $("#Agendarnombres").val(),
			"papellido": $("#Agendarpapellido").val(),
			"sapellido": ($("#Agendarsapellido").val()) ? $("#Agendarsapellido").val() : '',
			"estCivil": $("#AgendarestCivil").val(),
			"sexo": $("#Agendarsexo").val(),
			"fecNac": $("#AgendarfecNac").val(),
			"paisProcedencia": $("#AgendarpaisProcedencia").val(),
			"dptoProcedencia": $("#AgendardptoProcedencia").val(),
			"mnpoProcedencia": $("#AgendarmnpoProcedencia").val(),
			"paisResidencia": '45',
			"dptoResidencia": $("#AgendardptoResidencia").val(),
			"mnpoResidencia": $("#AgendarmnpoResidencia").val(),
			"direccionResidencia": $("#AgendardireccionResidencia").val(),
			"zonaResidencia": $("#AgendarzonaResidencia").val(),
			"telefono": ($("#Agendartelefono").val()) ? $("#Agendartelefono").val() : '',
			"status_migratorio": $("#Agendarstatus_migratorio").val(),
			"perfilPacie": ($("#AgendarperfilPacie").val()) ? $("#AgendarperfilPacie").val() : '',
			"movilidadPacie": $("#AgendarmovilidadPacie").val(),
			"tipoMoviliPAc": ($("#AgendartipoMoviliPAc").val()) ? $("#AgendartipoMoviliPAc").val() : '',
			"BDUA": ($("#AgendarBDUA").val()) ? $("#AgendarBDUA").val() : '',
			"eapb": ($("#Agendareapb").val()) ? $("#Agendareapb").val() : '',
			"tipoPoblacion": ($("#AgendartipoPoblacion").val()) ? $("#AgendartipoPoblacion").val() : '',
			"regimen": ($("#Agendarregimen").val()) ? $("#Agendarregimen ").val(): '',
			"perEtnica": ($("#AgendarperEtnica").val()) ? $("#AgendarperEtnica").val() : '',
			"pueIndigena": ($("#AgendarpueIndigena").val()) ? $("#AgendarpueIndigena").val() : '',
			"fecha_registro": f.getDate() + " de " + meses[(f.getMonth() +1)] + " de " + f.getFullYear(),
			"usuario_regitraid": usuario.numid,
			"usuario_regitratipoid": usuario.tipoid,
			"usuario_registrainst": usuario.institucion,
			"aceptaTerminos": ($("#aceptaTerminosAdm").val()) ? $("#aceptaTerminosAdm").val() : '',
			"OtraDireccion": ($("#AgendarOtraDireccion").val()) ? $("#AgendarOtraDireccion").val() : '',
			"correoElec": ($("#AgendarcorreoElec").val()) ? $("#AgendarcorreoElec").val() : '',
			"tiemrpoingresoColo": ($("#AgendartiemrpoingresoColo").val()) ? $("#AgendartiemrpoingresoColo").val() : '',
			"remitidoP": ($("#AgendarremitidoP").val()) ? $("#AgendarremitidoP").val() : '',
			"remitidoPDesc": ($("#AgendarremitidoPDesc").val()) ? $("#AgendarremitidoPDesc").val() : '',
			"otroDocumRepNum": ($("#AgendarotroDocumRepNum").val()) ? $("#AgendarotroDocumRepNum").val() : '',
			"rumv": ($("#Agendarrumv").val()) ? $("#Agendarrumv").val() : '',
			"rumvNum": ($("#AgendarrumvNum").val()) ? $("#AgendarrumvNum").val() : '',
			"PPT": ($("#AgendarPPT").val()) ? $("#AgendarPPT").val() : '',
			"PPTNum": ($("#AgendarPPTNum").val()) ? $("#AgendarPPTNum").val() : '',
			'estado': 1
		}
		console.log(regPaciente);
		$.ajax({
			url: "https://api.gimmids.com/pruebas/servicios/registrarPaciente.php",
			type: "post",
			data: {'datos':regPaciente, 'key':'GimmidsApp'  },
			async:false,
		}).done(function(res){
			var data=JSON.parse(res);
			if(data.STATUS=='OK'){

				regPaciente.id = data.ID;
				pacientes.push(regPaciente);
				localStorage.setItem('paciente', JSON.stringify(regPaciente));
				fs.writeFileSync(__dirname+'/json/pacientes.json', JSON.stringify(pacientes));	
				alert('Paciente registrado!..');
				$("#admisionar-modal").modal('hide');

				$("#AgendarID").val(regPaciente.id);
				$("#AgendarIDJSON").val(regPaciente.idJSON);
				$("#AgendartipoidRegPacAdmision").val(regPaciente.tipoidRegPac);
				$("#AgendaridRegPacAdmision").val(regPaciente.idRegPac);
				$("#AgendarotroDocumRepAdmision").val(regPaciente.otroDocumRep);
				$("#AgendarSexo").val(regPaciente.sexo);
				$("#AgendarNombresAdmision").val(regPaciente.nombres + ' ' + regPaciente.papellido + ' ' + regPaciente.sapellido);
				$("#AgendartipoidRegPac").val(null);
				$("#AgendaridRegPac").val(null);
				$("#AgendarotroDocumRep").val(null);
				
				$.post('https://api.gimmids.com/pruebas/servicios/listarUsuarios.php',{'institucion':usuario.institucion,'key':'GimmidsApp' }, function(dataprof){
					console.log(dataprof);
					if(dataprof.STATUS="OK"){
						var contprof='<option></option>';
						for(var tyu=0;tyu<dataprof.DATA.length;tyu++){
							console.log(dataprof.DATA[tyu]);
							if(dataprof.DATA[tyu].permiso_hamb==1){
								contprof+='<option value="'+dataprof.DATA[tyu].numid+'">'+dataprof.DATA[tyu].nombres+'</option>';
							}
						}
						$("#AgendarpprofeAgendarAdmision").html(contprof);
				
					}else{
						alert('Error al listar profesionales');
					}
				},"JSON").fail(function(e){
					alert('Error en el servidor al listar profesionales');
					
				});
				
				
				$("#regAdmision-modal").modal('show');


			}else{

				if (confirm('Problemas al registrar paciente al servidor. Desea volver a intentarlo?')) {
					registrarPaciente(1);
				}

			}
			
		}).fail(function() { 

			if (confirm('Problemas al registrar paciente al servidor. Desea volver a intentarlo?')) {
				registrarPaciente(1);
			} 

		});
	}else{
		regPaciente = {
			'id': 0,
			'idJSON': consecutivoJSONPacientes,
			"tipoidRegPac": $("#tipoidRegPac").val(),
			"idRegPac": $("#idRegPac").val(),
			"otroDocumRep": ($("#otroDocumRep").val()) ? $("#otroDocumRep").val() : '',
			"nombres": $("#nombres").val(),
			"papellido": $("#papellido").val(),
			"sapellido": ($("#sapellido").val()) ? $("#sapellido").val() : '',
			"estCivil": $("#estCivil").val(),
			"sexo": $("#sexo").val(),
			"fecNac": $("#fecNac").val(),
			"paisProcedencia": $("#paisProcedencia").val(),
			"dptoProcedencia": $("#dptoProcedencia").val(),
			"mnpoProcedencia": $("#mnpoProcedencia").val(),
			"paisResidencia": '45',
			"dptoResidencia": $("#dptoResidencia").val(),
			"mnpoResidencia": $("#mnpoResidencia").val(),
			"direccionResidencia": $("#direccionResidencia").val(),
			"zonaResidencia": $("#zonaResidencia").val(),
			"telefono": ($("#telefono").val()) ? $("#telefono").val() : '',
			"status_migratorio": $("#status_migratorio").val(),
			"perfilPacie": ($("#perfilPacie").val()) ? $("#perfilPacie").val() : '',
			"movilidadPacie": $("#movilidadPacie").val(),
			"tipoMoviliPAc": ($("#tipoMoviliPAc").val()) ? $("#tipoMoviliPAc").val() : '',
			"BDUA": ($("#BDUA").val()) ? $("#BDUA").val() : '',
			"eapb": ($("#eapb").val()) ? $("#eapb").val() : '',
			"tipoPoblacion": ($("#tipoPoblacion").val()) ? $("#tipoPoblacion").val() : '',
			"regimen": ($("#regimen").val()) ? $("#regimen ").val(): '',
			"perEtnica": ($("#perEtnica").val()) ? $("#perEtnica").val() : '',
			"pueIndigena": ($("#pueIndigena").val()) ? $("#pueIndigena").val() : '',
			
			"fecha_registro": f.getDate() + " de " + meses[(f.getMonth() +1)] + " de " + f.getFullYear(),
			"usuario_regitraid": usuario.numid,
			"usuario_regitratipoid": usuario.tipoid,
			"usuario_registrainst": usuario.institucion,
			"aceptaTerminos": ($("#aceptaTerminosAdm").val()) ? $("#aceptaTerminosAdm").val() : '',
			"OtraDireccion": ($("#OtraDireccion").val()) ? $("#OtraDireccion").val() : '',
			"correoElec": ($("#correoElec").val()) ? $("#correoElec").val() : '',
			"tiemrpoingresoColo": ($("#tiemrpoingresoColo").val()) ? $("#tiemrpoingresoColo").val() : '',
			"remitidoP": ($("#remitidoP").val()) ? $("#remitidoP").val() : '',
			"remitidoPDesc": ($("#remitidoPDesc").val()) ? $("#remitidoPDesc").val() : '',
			"otroDocumRepNum": ($("#otroDocumRepNum").val()) ? $("#otroDocumRepNum").val() : '',
			"rumv": ($("#rumv").val()) ? $("#rumv").val() : '',
			"rumvNum": ($("#rumvNum").val()) ? $("#rumvNum").val() : '',
			"PPT": ($("#PPT").val()) ? $("#PPT").val() : '',
			"PPTNum": ($("#PPTNum").val()) ? $("#PPTNum").val() : '',
			'estado': 1
		}
		$.ajax({
			url: "https://api.gimmids.com/pruebas/servicios/registrarPaciente.php",
			type: "post",
			data: {'datos':regPaciente, 'key':'GimmidsApp'  },
			async:false,
		}).done(function(res){
			var data=JSON.parse(res);
			if(data.STATUS=='OK'){

				regPaciente.id = data.ID;
				pacientes.push(regPaciente);
				localStorage.setItem('paciente', JSON.stringify(regPaciente));
				fs.writeFileSync(__dirname+'/json/pacientes.json', JSON.stringify(pacientes));	
				localStorage.setItem('entrada', 'ambulatorio');
				alert('Paciente registrado local y remotamente!..');
				ipc.send('ventana-hija', 'paciente');

			}else{

				if (confirm('Problemas al registrar paciente al servidor. Desea volver a intentarlo?')) {
					registrarPaciente(2);
				}else{

					regPaciente.estado = 0;
					pacientes.push(regPaciente);
					localStorage.setItem('paciente', JSON.stringify(regPaciente));
					fs.writeFileSync(__dirname+'/json/pacientes.json', JSON.stringify(pacientes));	
					localStorage.setItem('entrada', 'ambulatorio');
					alert('Paciente registrado localmente!..');
					ipc.send('ventana-hija', 'paciente');

				}

			}
			
		}).fail(function() { 

			if (confirm('Problemas al registrar paciente al servidor. Desea volver a intentarlo?')) {
				registrarPaciente(2);
			} else{
				regPaciente.estado = 0;
				pacientes.push(regPaciente);
				localStorage.setItem('paciente', JSON.stringify(regPaciente));
				fs.writeFileSync(__dirname+'/json/pacientes.json', JSON.stringify(pacientes));	
				localStorage.setItem('entrada', 'ambulatorio');
				alert('Paciente registrado localmente!..');
				ipc.send('ventana-hija', 'paciente');
			}
			
		});
	} 


}

function obtenerConsecutivoJSONPacientes(){
	var conse = 0;
	for (var i = 0; i < pacientes.length; i++) {
		 if (pacientes[i].idJSON > conse) {
			conse = parseInt(pacientes[i].idJSON);
		}
	}
	return conse + 1;
}
//----------------VALIDACIONES para el registro de paciente--------------------------


function validarISO(siglas) {
	
	for (var i = 0; i < iso3166.length; i++) {
		if (iso3166[i].COD == siglas) {
			return 1;
		}
	}
	return 0;
}
function buscarPaciente(tipoid, numid){
	console.log(pacientes);
	for (var i = 0; i < pacientes.length; i++) {
		 
		if (pacientes[i].tipoidRegPac == tipoid && pacientes[i].idRegPac == numid) {
			return pacientes[i];
		}


	}
	return "LIBRE";
}
function cargaNumHistClinic(tipoid,numid, historia){
	 
	$("#"+historia+"").val($("#"+tipoid+"").val()+$("#"+numid+"").val());
}
function numOtroDocument(tipo, num){
	if($('#'+tipo).val()!='NINGUNO'){
		$('#'+num).removeAttr('disabled');
	}else if($('#'+tipo).val()=='NINGUNO'){
		
		$('#'+num).attr('disabled', true);
		$('#'+num).val('');
	}
}
function calcularEdad(div, div2){
	
	var nacimiento = $("#"+div).val();
	var values = nacimiento.split("-");

	var dia = values[2];
	var mes = values[1];
	var ano = values[0];

	// cogemos los valores actuales
	var fecha_hoy = new Date();
	var ahora_ano = fecha_hoy.getYear();
	var ahora_mes = fecha_hoy.getMonth() + 1;
	var ahora_dia = fecha_hoy.getDate();

	// realizamos el calculo
	var edad = (ahora_ano + 1900) - ano;
	if (ahora_mes < mes) {
		edad--;
	}
	if ((mes == ahora_mes) && (ahora_dia < dia)) {
		edad--;
	}
	if (edad > 1900) {
		edad -= 1900;
	}

	// calculamos los meses
	var meses = 0;
	if (ahora_mes > mes)
		meses = ahora_mes - mes;
	if (ahora_mes < mes)
		meses = 12 - (mes - ahora_mes);
	if (ahora_mes == mes && dia > ahora_dia)
		meses = 11;
	
	// calculamos los dias
	var dias = 0;
	if (ahora_dia > dia)
		dias = ahora_dia - dia;
	if (ahora_dia < dia) {
		var ultimoDiaMes = new Date(ahora_ano, ahora_mes, 0);
		dias = ultimoDiaMes.getDate() - (dia - ahora_dia);
	}

	
	$("#"+div2).val(edad +' años '+ (parseInt(meses-1)) +' mes(es) y '+ dias +'días');
 
            
}
function seleccionPais(pais, dpt, mnp){
	console.log($("#"+pais).val());
	var condpto='';
	var conmnpo='';
	if($("#"+pais).val()=='45'){
		//colombia
		condpto+='<select id="'+dpt+'" name="'+dpt+'"  class="form-control" onchange="Javascript: seleccionDpto(`'+pais+'`,`'+dpt+'`,`'+mnp+'`);"><option></option>';
		for(var ty=0;ty<dptos.length;ty++){
			condpto+='<option value="'+dptos[ty].Id+'">'+dptos[ty].nombre+'</option>';
		}
		condpto+='</select>';
		conmnpo+='<select id="'+mnp+'" name="'+mnp+'"  class="form-control"><option></option></select>';
		

	}else if($("#"+pais).val()=='242'){
		//venezuela
		condpto+='<select id="'+dpt+'" name="'+dpt+'" onchange="Javascript: seleccionDpto(`'+pais+'`,`'+dpt+'`,`'+mnp+'`);" class="form-control"><option></option>';
		for(var ty=0;ty<dptosv.length;ty++){
			condpto+='<option value="'+dptosv[ty].Id+'">'+dptosv[ty].nombre+'</option>';
		}
		condpto+='</select>';
		conmnpo+='<select id="'+mnp+'" name="'+mnp+'"  class="form-control"><option></option></select>';
		
	}else{

		condpto+='<input type="text" id="'+dpt+'" name="'+dpt+'"  class="form-control">';
		conmnpo+='<input type="text" id="'+mnp+'" name="'+mnp+'"  class="form-control">';
		 

	}
	$("#"+dpt+"div").html(condpto);
	$("#"+mnp+"div").html(conmnpo);

}
function seleccionDpto(pais, dpt, mnp){
	 console.log('seleciionando dpt')
	var conmnpo='';
	if($("#"+pais).val()=='45'){
		//colombia
		console.log('colombia');
		if(mnp=='AgendarmnpoResidencia' || mnp=='mnpoResidencia'){
			conmnpo+='<option></option>';
		
			for(var ty=0;ty<mnpos.length;ty++){
				if(mnpos[ty].cod_dptop==$("#"+dpt).val()){
					conmnpo+='<option value="'+mnpos[ty].cod_mnpo+'">'+mnpos[ty].nombre_mnpo+'</option>';
				}
			}
		}else{
			conmnpo+='<select id="'+mnp+'" name="'+mnp+'"  class="form-control">';
		
			for(var ty=0;ty<mnpos.length;ty++){
				if(mnpos[ty].cod_dptop==$("#"+dpt).val()){
					conmnpo+='<option value="'+mnpos[ty].cod_mnpo+'">'+mnpos[ty].nombre_mnpo+'</option>';
				}
			}
			conmnpo+='</select>';
		}
		
		

	}else if($("#"+pais).val()=='242'){
		//venezuela
		console.log('venezuela');
		conmnpo+='<select id="'+mnp+'" name="'+mnp+'"  class="form-control">';
		
		for(var ty=0;ty<mnposv.length;ty++){
			if(mnposv[ty].cod_dptop==$("#"+dpt).val()){
				conmnpo+='<option value="'+mnposv[ty].nombre_mnpo+'">'+mnposv[ty].nombre_mnpo+'</option>';
			}
		}
		conmnpo+='</select>';
		
	} else{
		conmnpo+='<input type="text" id="'+mnp+'" name="'+mnp+'"  class="form-control">';
			
	}
	if(mnp=='AgendarmnpoResidencia' || mnp=='mnpoResidencia'){
		$("#"+mnp).html(conmnpo);

	}else{
		$("#"+mnp+"div").html(conmnpo);
	}
}
function seleccTipoMovilidad(uno,dos){
	 
	if($("#"+uno).val()=='DESPLAZAMIENTO'){
		$("#"+dos).removeAttr('disabled');
	}else{
		$("#"+dos).attr('disabled', true);
		$("#"+dos).val('')
	}
}
function seleccBDUA(uno,dos){
	 
	if($("#"+uno).val()!='NO ASEGURADO'){
		$("#"+dos).removeAttr('disabled');
	}else{
		$("#"+dos).attr('disabled', true);
		$("#"+dos).val('')
	}
}
function seleccPertEtnica(uno,dos){
	 
	if($("#"+uno).val()=='4'){
		$("#"+dos).removeAttr('disabled');
		$("#"+dos).val('');
	}else{
		$("#"+dos).attr('disabled', true);
		$("#"+dos).val('NA');
	}
}
function seleccrumv(uno,dos){
	 
	if($("#"+uno).val()=='SI'){
		$("#"+dos).removeAttr('disabled');
		$("#"+dos).val('');
	}else{
		$("#"+dos).attr('disabled', true);
		$("#"+dos).val('');
	}
}
function seleccppt(uno,dos){
	 
	if($("#"+uno).val()=='SI'){
		$("#"+dos).removeAttr('disabled');
		$("#"+dos).val('');
	}else{
		$("#"+dos).attr('disabled', true);
		$("#"+dos).val('');
	}
}
 
//---AGENDA----
function listarAgenda(){
	console.log('cargando agenda');
	var listadoAgendado=[];
	n =  new Date();
	//Año
	y = n.getFullYear();
	//Mes
	m = n.getMonth() + 1;
	//Día
	d = n.getDate();
	if(m<10){
		m='0'+m;
	}
	if(d<10){
		d='0'+d;
		
	}
	var fecah=y+'-'+m+'-'+d;
	console.log(fecah); 
	var dataIn = { 
		'id': usuario.numid ,
		'key':'GimmidsApp'
	};
	var contAgenda=''; 
	if(usuario.permiso_agendar==1){
		
		$.post('https://api.gimmids.com/pruebas/servicios/listarAgendaInstituto.php', { 'datos': dataIn }, function(data) {
			console.log(data);
			if (data.STATUS == 'OK') { 
				if (data.DATA.length > 0) {
					for(var trr=0;trr<data.DATA.length;trr++){
						contAgenda+=`<tr >
									<td>`+data.DATA[trr].nombres+`</td>
									<td>`+data.DATA[trr].AgendartipoidRegPacAdmision+`</td>
									<td>`+data.DATA[trr].AgendaridRegPacAdmision+`</td>
									<td>`+data.DATA[trr].AgendarNombresAdmision+`</td>
									<td>`+data.DATA[trr].AgendarServicioAdmision+`</td>
									<td>`+data.DATA[trr].AgendarFechaAgendarAdmision+`</td>
									<td>`+data.DATA[trr].AgendarHoraAgendarAdmision+`</td>
									<td>
										<button class="btn btn-success btn-sm" onclick="atenderConsulta('`+data.DATA[trr].Id+`','`+data.DATA[trr].AgendartipoidRegPacAdmision+`','`+data.DATA[trr].AgendaridRegPacAdmision+`','`+data.DATA[trr].AgendarNombresAdmision+`','`+data.DATA[trr].AgendarServicioAdmision+`')">Atender</button>
										<button class="btn btn-danger btn-sm" onclick="cancelarConsulta(`+data.DATA[trr].Id+`)">Cancelar</button>
									</td>
									</tr>`; 
					}
					$("#listadoAgendaBody").html(contAgenda);
						
					$('#listadoAgenda').dataTable();
						
				}
			}
		}, "JSON").fail(function(e){
			alert(e);
		});


	}else{
		$.post('https://api.gimmids.com/pruebas/servicios/listarAgendaProfesionalID.php', { 'datos': dataIn }, function(data) {
			console.log(data);
			if (data.STATUS == 'OK') {
				var cont = '';
				if (data.DATA.length > 0) {
					
					console.log(data.DATA)
					for(var trr=0;trr<data.DATA.length;trr++){
					 
						if(data.DATA[trr].AgendarFechaAgendarAdmision==fecah){
							console.log('fecha igual');
							contAgenda+=`<tr>
							<td>`+data.DATA[trr].nombres+`</td>
							<td>`+data.DATA[trr].AgendartipoidRegPacAdmision+`</td>
							<td>`+data.DATA[trr].AgendaridRegPacAdmision+`</td>
							<td>`+data.DATA[trr].AgendarNombresAdmision+`</td>
							<td>`+data.DATA[trr].AgendarServicioAdmision+`</td>
							<td>`+data.DATA[trr].AgendarFechaAgendarAdmision+`</td>
							<td>`+data.DATA[trr].AgendarHoraAgendarAdmision+`</td>
							<td>
								<button class="btn btn-success btn-sm" onclick="atenderConsulta('`+data.DATA[trr].Id+`','`+data.DATA[trr].AgendartipoidRegPacAdmision+`','`+data.DATA[trr].AgendaridRegPacAdmision+`','`+data.DATA[trr].AgendarNombresAdmision+`','`+data.DATA[trr].AgendarServicioAdmision+`')">Atender</button>
										
							</td>
							</tr>`;
						}
						$("#listadoAgendaBody").html(contAgenda);
						
						$('#listadoAgenda').dataTable();
						
					}
				 


				}
			}
		}, "JSON");


	}
}

//---ADMINISTRACION

function listarUsuariosGimmids(){
	
	$.post('https://api.gimmids.com/pruebas/servicios/listarUsuariosGimmids.php',{'key':'GimmidsApp' }, function(data){
		console.log(data);
		
		if (data.STATUS == "OK") {
			if (data.DATA.length > 0) {
				var con = '';
				for (var i = 0; i < data.DATA.length; i++) {
					con += '<tr>';
					// +'<td><button class="btn btn-sm btn-info" onclick="Javascript:editarUsuario(`'+data.DATA[i].id+'`,`'+data.DATA[i].tipoid+'`, `'+data.DATA[i].numid+'`, `'+data.DATA[i].nombres+'`, `'+data.DATA[i].profesion+'`, `'+data.DATA[i].reg_prof+'`, `'+data.DATA[i].institucion+'`, `'+data.DATA[i].user+'`, `'+data.DATA[i].pass+'`, `'+data.DATA[i].direccion+'`, `'+data.DATA[i].permiso_agendar+'`, `'+data.DATA[i].permiso_registro+'`, `'+data.DATA[i].permiso_procedimientos+'`, `'+data.DATA[i].permiso_informes+'`, `'+data.DATA[i].permiso_usuarios+'`);">EDITAR</button></td>';
					con += '<td>' + data.DATA[i].tipoid + '</td>' +
						'<td>' + data.DATA[i].numid + '</td>' +
						'<td>' + data.DATA[i].nombres + '</td>' +
						'<td>' + data.DATA[i].profesion + '</td>' +
						'<td>' + data.DATA[i].reg_prof + '</td>' +
						'<td>' + data.DATA[i].institucion + '</td>' +
						'<td>' + data.DATA[i].user + '</td>' +
						'<td>' + data.DATA[i].pass + '</td>' +
						'<td>' + data.DATA[i].direccion + '</td>';

					con += (data.DATA[i].permiso_agendar == 1) ? '<td>SI</td>' : '<td>NO</td>';
					con += (data.DATA[i].permiso_registro == 1) ? '<td>SI</td>' : '<td>NO</td>';
					con += (data.DATA[i].permiso_procedimientos == 1) ? '<td>SI</td>' : '<td>NO</td>';
					con += (data.DATA[i].permiso_informes == 1) ? '<td>SI</td>' : '<td>NO</td>';
					con += (data.DATA[i].permiso_usuarios == 1) ? '<td>SI</td>' : '<td>NO</td>';
					con+='</tr>';	
				}
				$("#listadoUsuariosBody").html(con);
				$('#listadoUsuarios').dataTable();
				
			} 
		}
	}, "JSON").fail(function(e) { 
		console.log(e);
		 alert('Error'+ e);
		
	});
}

function registrarUsuarioGimmids(){
	console.log('editando usuario');
	if(confirm('Registrar Usuario?')){
		var dataIn = {
			'id': $("#numid_user").val(),
			'tipoid': $("#tipoid_user").val(),
			'numid': $("#numid_user").val(),
			'nombres': $("#nombres_user").val(),
			'profesion': $("#profesion_user").val(),
			'reg_prof': $("#regprof_user").val(),
			'institucion': $("#insti_user").val(),
			'user': $("#user_user").val(),
			'pass': $("#pass_user").val(),
			'direccion': $("#direccion_user").val(),
			'permiso_agendar': ($("#permiso_agendar").prop('checked')) ? 1 : 0,
			'permiso_registro': ($("#permiso_registro").prop('checked')) ? 1 : 0,
			'permiso_procedimientos': ($("#permiso_procedimientos").prop('checked')) ? 1 : 0,
			'permiso_informes': ($("#permiso_informes").prop('checked')) ? 1 : 0,
			'permiso_usuarios': ($("#permiso_usuarios").prop('checked')) ? 1 : 0
		}
		console.log(dataIn);
		$.ajax({
			url: "https://api.gimmids.com/pruebas/servicios/registrarUsuario.php",
			type: "post",
			dataType: "html",
			data:{ 'datos': dataIn,'key':'GimmidsApp'  },
			async:false
		}).done(function(res){
			console.log(res);
			 try {
				data=JSON.parse(res);
				if (data.STATUS == 'OK') {
                    alert("Usuario  registrado con exito!..");
                    location.reload();

                } else {
                    alert('Error al registrar usuario!..');
                }
			}catch(e){
	
			} 	
		}).fail(function(e) { 
			console.log(e);
			 alert('Error'+ e);
			
		});
	}
}

function registrarMedicamentoGimmids() {
	console.log(medicamentos);
	if(confirm('RegistrarMedicamento?')){
			
		var dataIn={'Id':$("#cod-medicamento").val(),'nombre': $("#nombre-medicamento").val()};
		console.log(dataIn);
		medicamentos.push(dataIn);
		fs.writeFileSync(__dirname+'/json/medicamentos.json', JSON.stringify(medicamentos));
		alert('medicamento registrado con exito!...');

	}
}
function listarMedicamentos(){
	var conter='';
	for(var t=0;t<medicamentos.length;t++){
		conter+='<tr>'+
					'<td>'+medicamentos[t].Id+'</td>'+
					'<td>'+medicamentos[t].nombre+'</td>'+
					'<td><a class="btn btn-danger btn-sm" onClick="eliminarMedicamento('+t+')">ELIMINAR</a></td>'+
				'</tr>'    ;
	}
	 $("#listadoMedicamentosBody").html(conter);
	 
	$('#listadoMedicamentos').DataTable();
	 
}

function  eliminarMedicamento(inde){
    if(confirm('Seguro de eliminar el medicamento?..')){
         medicamentos.splice(inde, 1);
		fs.writeFileSync(__dirname+'/json/medicamentos.json', JSON.stringify(medicamentos));
    }
   
}

function generarRIPS(){
	//
	ipc.send('guardarRipsTXT');

}

ipc.on('guardarRipsTXTU', function(event, path) {

	cantAC = 0;
	cantAP = 0;
	cantAF = 0;
	cantUS = 0;
	var contAC = '';
	var contUS = '';
	var contAF = '';
	var contAP = '';
	var contCT = '';

	valirptep = [];
	valirptep2 = [];
	var ripscodprest=$("#rips-codprest").val();
	var ripsnombrePres=$("#rips-nombrePres").val();
	var ripstipoidPres=$("#rips-tipoidPres").val();
	var ripsnumidPres=$("#rips-numidPres").val();
	var ripscodentPres=$("#rips-codentPres").val();
	var ripsnombrentPres=$("#rips-nombrentPres").val();
	var ripsmesReporrtRipsUS=$("#mesReporrtRipsUS").val();
	var ripsanoReporrtRipsUS=$("#anoReporrtRipsUS").val();

	var pacientesMesAten=[];

	console.log(ripsmesReporrtRipsUS);
	console.log(ripsanoReporrtRipsUS);
	if (generales.length > 0) {

		for (var i = 0; i < generales.length; i++) {
			//datPaciente = buscarPacienteDatosRips(generales[i].tipoid_pac, generales[i].numid_pac);
			//console.log(generales[i].fechaConsulta);
			var valmes=generales[i].fechaConsulta.split('-');
			//console.log(valmes);
			if(valmes[1]==ripsmesReporrtRipsUS && valmes[2]==ripsanoReporrtRipsUS){
				//console.log('iguales');
				cantAC = cantAC + 1;
				var generalesContnue= cantAC + ',' +
				ripscodprest + ',' +
				generales[i].tipoid_pac + ',' +
				generales[i].numid_pac + ',' +
				codificarFechaRIPS(generales[i].fechaConsulta) + ',' + 
				',';
	
				generalesContnue += generales[i].tipoConsulta + ',' +
									generales[i].finalidadConsulta + ',' +
									generales[i].causaExternaConsulta + ',';
				diagnostCon = decodificarGimmids(generales[i].listadoCIEPa);
				 
				if(generales[i].listadoCIEPa){
					if (diagnostCon.length == 1) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = '';
						diagrel2 = '';
						diagrel3 = '';
		
					} else if (diagnostCon.length == 2) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = '';
						diagrel3 = '';
		
		
					} else if (diagnostCon.length == 3) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = '';
		
					} else if (diagnostCon.length >= 4) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = diagnostCon[3][0];
		
					}
				}else{
					diagPrin = '';
					diagrel1 = '';
					diagrel2 = '';
					diagrel3 = '';
				}
				generalesContnue += diagPrin + ',' +
					diagrel1 + ',' +
					diagrel2 + ',' +
					diagrel3 + ',' +
					generales[i].tipoDiagnosPrinc + ',' +
					'0,' +
					'0,' +
					'0\r\n'; 
				//procedemos a añadir al archivo US los datos del usuario
				var pacienteUs=buscarPacienteIdent(generales[i].tipoid_pac, generales[i].numid_pac);
				console.log(pacienteUs);
				if(pacienteUs!=null){
					var valUsAten=0;
					for(var w=0;w<pacientesMesAten.length;w++){
						if(pacientesMesAten[w].tipoidRegPac==pacienteUs.tipoidRegPac && pacientesMesAten[w].idRegPac==pacienteUs.idRegPac){
							valUsAten=1;
						}
					}
					
					if(valUsAten==0){
						pacientesMesAten.push(pacienteUs);
						cantUS=cantUS+1;
						var pnombre = '';
						var snombre = ''; 
						var eadp = (pacienteUs.eapb == null) ? '' : pacienteUs.eapb;
						var nombrsplit = pacienteUs.nombres.split(' ');
	
						if (nombrsplit.length <= 2) {
							pnombre = nombrsplit[0];
							snombre = nombrsplit[1];
						} else {
		
							pnombre = nombrsplit[0];
							for (var rti = 1; rti < nombrsplit.length; rti++) {
								snombre += nombrsplit[rti] + ' ';
							}
						}
						var edadSplit = calcularEdadReporte(pacienteUs.fecNac).split(' ');
					
						var eda = (edadSplit[1] == 'AÑOS') ? 1 : (edadSplit[1] == 'MESES') ? 2 : 3;
						var dptoRee = (pacienteUs.dptoResidencia < 10) ? '0' + pacienteUs.dptoResidencia : pacienteUs.dptoResidencia;
						var mnpoRee = (pacienteUs.mnpoResidencia < 10) ? '0' + pacienteUs.mnpoResidencia : pacienteUs.mnpoResidencia;
					   
						var contentUS=pacienteUs.tipoidRegPac + ',' +
									pacienteUs.idRegPac + ',' +
									eadp + ',' +
									pacienteUs.regimen + ',' +
									pacienteUs.papellido + ',' +
									pacienteUs.sapellido + ',' +
									pnombre + ',' +
									snombre + ',' +
									edadSplit[0] + ',' +
									eda + ',' +
									pacienteUs.sexo + ',' +
									dptoRee + ',' +
									mnpoRee + ',' +
									pacienteUs.zonaResidencia + '\r\n';
	
						contUS+=contentUS;
	
					}
					//SE PROCEDE A CREAR EL ARCHIVO DE FACTURACION

					contAF+=ripscodprest+','+
							ripsnombrePres+','+
							ripstipoidPres+','+
							ripsnumidPres+','+
							cantAC+','+
							codificarFechaRIPS(generales[i].fechaConsulta) + ',' + 
							'01/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';

					if(ripsmesReporrtRipsUS=='02'){
						contAF+='28/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else if(ripsmesReporrtRipsUS=='01' || ripsmesReporrtRipsUS=='03' || ripsmesReporrtRipsUS=='05' || ripsmesReporrtRipsUS=='07' || ripsmesReporrtRipsUS=='08' || ripsmesReporrtRipsUS=='10' || ripsmesReporrtRipsUS=='12'){
						contAF+='31/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else{
						contAF+='30/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}
					contAF+=ripscodentPres+','+
							ripsnombrentPres+',,,,0,0,0,0\r\n';

					cantAF=cantAF+1;
				}else{
					generalesContnue='';
				}
					
	
				contAC+=generalesContnue;
				
			}
			
		}
	} 
	if (enfermeria.length > 0) {

		for (var i = 0; i < enfermeria.length; i++) {
			//datPaciente = buscarPacienteDatosRips(enfermeria[i].tipoid_pac, enfermeria[i].numid_pac);
			console.log(enfermeria[i].fechaConsulta);
			var valmes=enfermeria[i].fechaConsulta.split('-');
			console.log(valmes);
			if(valmes[1]==ripsmesReporrtRipsUS && valmes[2]==ripsanoReporrtRipsUS){
				console.log('iguales');
				cantAC = cantAC + 1;
				var enfermeriaContnue= cantAC + ',' +
				ripscodprest + ',' +
				enfermeria[i].tipoid_pac + ',' +
				enfermeria[i].numid_pac + ',' +
				codificarFechaRIPS(enfermeria[i].fechaConsulta) + ',' + 
				',';
	
				enfermeriaContnue += enfermeria[i].tipoConsulta + ',' +
									enfermeria[i].finalidadConsulta + ',' +
									enfermeria[i].causaExternaConsulta + ',';
				diagnostCon = decodificarGimmids(enfermeria[i].listadoCIEPa);
				if(enfermeria[i].listadoCIEPa){
					if (diagnostCon.length == 1) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = '';
						diagrel2 = '';
						diagrel3 = '';
		
					} else if (diagnostCon.length == 2) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = '';
						diagrel3 = '';
		
		
					} else if (diagnostCon.length == 3) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = '';
		
					} else if (diagnostCon.length >= 4) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = diagnostCon[3][0];
		
					}
				}else{
					diagPrin = '';
					diagrel1 = '';
					diagrel2 = '';
					diagrel3 = '';
				}
				
				enfermeriaContnue += diagPrin + ',' +
					diagrel1 + ',' +
					diagrel2 + ',' +
					diagrel3 + ',' +
					enfermeria[i].tipoDiagnosPrinc + ',' +
					'0,' +
					'0,' +
					'0\r\n'; 
				//procedemos a añadir al archivo US los datos del usuario
				var pacienteUs=buscarPacienteIdent(enfermeria[i].tipoid_pac, enfermeria[i].numid_pac);
				if(pacienteUs!=null){
					var valUsAten=0;
					for(var w=0;w<pacientesMesAten.length;w++){
						if(pacientesMesAten[w].tipoidRegPac==pacienteUs.tipoidRegPac && pacientesMesAten[w].idRegPac==pacienteUs.idRegPac){
							valUsAten=1;
						}
					}
					
					if(valUsAten==0){
						pacientesMesAten.push(pacienteUs);
					
						cantUS=cantUS+1;
						var pnombre = '';
						var snombre = ''; 
						var eadp = (pacienteUs.eapb == null) ? '' : pacienteUs.eapb;
						var nombrsplit = pacienteUs.nombres.split(' ');
	
						if (nombrsplit.length <= 2) {
							pnombre = nombrsplit[0];
							snombre = nombrsplit[1];
						} else {
		
							pnombre = nombrsplit[0];
							for (var rti = 1; rti < nombrsplit.length; rti++) {
								snombre += nombrsplit[rti] + ' ';
							}
						}
						var edadSplit = calcularEdadReporte(pacienteUs.fecNac).split(' ');
					
						var eda = (edadSplit[1] == 'AÑOS') ? 1 : (edadSplit[1] == 'MESES') ? 2 : 3;
						var dptoRee = (pacienteUs.dptoResidencia < 10) ? '0' + pacienteUs.dptoResidencia : pacienteUs.dptoResidencia;
						var mnpoRee = (pacienteUs.mnpoResidencia < 10) ? '0' + pacienteUs.mnpoResidencia : pacienteUs.mnpoResidencia;
					   
						var contentUS=pacienteUs.tipoidRegPac + ',' +
									pacienteUs.idRegPac + ',' +
									eadp + ',' +
									pacienteUs.regimen + ',' +
									pacienteUs.papellido + ',' +
									pacienteUs.sapellido + ',' +
									pnombre + ',' +
									snombre + ',' +
									edadSplit[0] + ',' +
									eda + ',' +
									pacienteUs.sexo + ',' +
									dptoRee + ',' +
									mnpoRee + ',' +
									pacienteUs.zonaResidencia + '\r\n';
	
						contUS+=contentUS;
	
					}
					//SE PROCEDE A CREAR EL ARCHIVO DE FACTURACION

					contAF+=ripscodprest+','+
							ripsnombrePres+','+
							ripstipoidPres+','+
							ripsnumidPres+','+
							cantAC+','+
							codificarFechaRIPS(enfermeria[i].fechaConsulta) + ',' + 
							'01/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';

					if(ripsmesReporrtRipsUS=='02'){
						contAF+='28/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else if(ripsmesReporrtRipsUS=='01' || ripsmesReporrtRipsUS=='03' || ripsmesReporrtRipsUS=='05' || ripsmesReporrtRipsUS=='07' || ripsmesReporrtRipsUS=='08' || ripsmesReporrtRipsUS=='10' || ripsmesReporrtRipsUS=='12'){
						contAF+='31/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else{
						contAF+='30/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}
					contAF+=ripscodentPres+','+
							ripsnombrentPres+',,,,0,0,0,0\r\n';

					cantAF=cantAF+1;
				}else{
					enfermeriaContnue='';
				}
					
	
				contAC+=enfermeriaContnue;
				
			}
			
		}
	} 
	if (psicologia.length > 0) {

		for (var i = 0; i < psicologia.length; i++) {
			//datPaciente = buscarPacienteDatosRips(psicologia[i].tipoid_pac, psicologia[i].numid_pac);
			console.log(psicologia[i].fechaConsulta);
			var valmes=psicologia[i].fechaConsulta.split('-');
			console.log(valmes);
			if(valmes[1]==ripsmesReporrtRipsUS && valmes[2]==ripsanoReporrtRipsUS){
				console.log('iguales');
				cantAC = cantAC + 1;
				var psicologiaContnue= cantAC + ',' +
				ripscodprest + ',' +
				psicologia[i].tipoid_pac + ',' +
				psicologia[i].numid_pac + ',' +
				codificarFechaRIPS(psicologia[i].fechaConsulta) + ',' + 
				',';
	
				psicologiaContnue += psicologia[i].tipoConsulta + ',' +
									psicologia[i].finalidadConsulta + ',' +
									psicologia[i].causaExternaConsulta + ',';
				diagnostCon = decodificarGimmids(psicologia[i].listadoCIEPa);
				 
				if(psicologia[i].listadoCIEPa){
					if (diagnostCon.length == 1) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = '';
						diagrel2 = '';
						diagrel3 = '';
		
					} else if (diagnostCon.length == 2) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = '';
						diagrel3 = '';
		
		
					} else if (diagnostCon.length == 3) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = '';
		
					} else if (diagnostCon.length >= 4) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = diagnostCon[3][0];
		
					}
				}else{
					diagPrin = '';
					diagrel1 = '';
					diagrel2 = '';
					diagrel3 = '';
				}
				psicologiaContnue += diagPrin + ',' +
					diagrel1 + ',' +
					diagrel2 + ',' +
					diagrel3 + ',' +
					psicologia[i].tipoDiagnosPrinc + ',' +
					'0,' +
					'0,' +
					'0\r\n'; 
				//procedemos a añadir al archivo US los datos del usuario
				var pacienteUs=buscarPacienteIdent(psicologia[i].tipoid_pac, psicologia[i].numid_pac);
				if(pacienteUs!=null){
					var valUsAten=0;
					for(var w=0;w<pacientesMesAten.length;w++){
						if(pacientesMesAten[w].tipoidRegPac==pacienteUs.tipoidRegPac && pacientesMesAten[w].idRegPac==pacienteUs.idRegPac){
							valUsAten=1;
						}
					}
					
					if(valUsAten==0){
						pacientesMesAten.push(pacienteUs);
					
						cantUS=cantUS+1;
						var pnombre = '';
						var snombre = ''; 
						var eadp = (pacienteUs.eapb == null) ? '' : pacienteUs.eapb;
						var nombrsplit = pacienteUs.nombres.split(' ');
	
						if (nombrsplit.length <= 2) {
							pnombre = nombrsplit[0];
							snombre = nombrsplit[1];
						} else {
		
							pnombre = nombrsplit[0];
							for (var rti = 1; rti < nombrsplit.length; rti++) {
								snombre += nombrsplit[rti] + ' ';
							}
						}
						var edadSplit = calcularEdadReporte(pacienteUs.fecNac).split(' ');
					
						var eda = (edadSplit[1] == 'AÑOS') ? 1 : (edadSplit[1] == 'MESES') ? 2 : 3;
						var dptoRee = (pacienteUs.dptoResidencia < 10) ? '0' + pacienteUs.dptoResidencia : pacienteUs.dptoResidencia;
						var mnpoRee = (pacienteUs.mnpoResidencia < 10) ? '0' + pacienteUs.mnpoResidencia : pacienteUs.mnpoResidencia;
					   
						var contentUS=pacienteUs.tipoidRegPac + ',' +
									pacienteUs.idRegPac + ',' +
									eadp + ',' +
									pacienteUs.regimen + ',' +
									pacienteUs.papellido + ',' +
									pacienteUs.sapellido + ',' +
									pnombre + ',' +
									snombre + ',' +
									edadSplit[0] + ',' +
									eda + ',' +
									pacienteUs.sexo + ',' +
									dptoRee + ',' +
									mnpoRee + ',' +
									pacienteUs.zonaResidencia + '\r\n';
	
						contUS+=contentUS;
	
					}
					//SE PROCEDE A CREAR EL ARCHIVO DE FACTURACION

					contAF+=ripscodprest+','+
							ripsnombrePres+','+
							ripstipoidPres+','+
							ripsnumidPres+','+
							cantAC+','+
							codificarFechaRIPS(psicologia[i].fechaConsulta) + ',' + 
							'01/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';

					if(ripsmesReporrtRipsUS=='02'){
						contAF+='28/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else if(ripsmesReporrtRipsUS=='01' || ripsmesReporrtRipsUS=='03' || ripsmesReporrtRipsUS=='05' || ripsmesReporrtRipsUS=='07' || ripsmesReporrtRipsUS=='08' || ripsmesReporrtRipsUS=='10' || ripsmesReporrtRipsUS=='12'){
						contAF+='31/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else{
						contAF+='30/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}
					contAF+=ripscodentPres+','+
							ripsnombrentPres+',,,,0,0,0,0\r\n';

					cantAF=cantAF+1;
				}else{
					psicologiaContnue='';
				}
					
	
				contAC+=psicologiaContnue;
				
			}
			
		}
	} 
	if (nutricional.length > 0) {

		for (var i = 0; i < nutricional.length; i++) {
			//datPaciente = buscarPacienteDatosRips(nutricional[i].tipoid_pac, nutricional[i].numid_pac);
			console.log(nutricional[i].fechaConsulta);
			var valmes=nutricional[i].fechaConsulta.split('-');
			console.log(valmes);
			if(valmes[1]==ripsmesReporrtRipsUS && valmes[2]==ripsanoReporrtRipsUS){
				console.log('iguales');
				cantAC = cantAC + 1;
				var nutricionalContnue= cantAC + ',' +
				ripscodprest + ',' +
				nutricional[i].tipoid_pac + ',' +
				nutricional[i].numid_pac + ',' +
				codificarFechaRIPS(nutricional[i].fechaConsulta) + ',' + 
				',';
	
				nutricionalContnue += nutricional[i].tipoConsulta + ',' +
									nutricional[i].finalidadConsulta + ',' +
									nutricional[i].causaExternaConsulta + ',';
				diagnostCon = decodificarGimmids(nutricional[i].listadoCIEPa);
				 
				if(nutricional[i].listadoCIEPa){
					if (diagnostCon.length == 1) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = '';
						diagrel2 = '';
						diagrel3 = '';
		
					} else if (diagnostCon.length == 2) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = '';
						diagrel3 = '';
		
		
					} else if (diagnostCon.length == 3) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = '';
		
					} else if (diagnostCon.length >= 4) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = diagnostCon[3][0];
		
					}
				}else{
					diagPrin = '';
					diagrel1 = '';
					diagrel2 = '';
					diagrel3 = '';
				}
				nutricionalContnue += diagPrin + ',' +
					diagrel1 + ',' +
					diagrel2 + ',' +
					diagrel3 + ',' +
					nutricional[i].tipoDiagnosPrinc + ',' +
					'0,' +
					'0,' +
					'0\r\n'; 
				//procedemos a añadir al archivo US los datos del usuario
				var pacienteUs=buscarPacienteIdent(nutricional[i].tipoid_pac, nutricional[i].numid_pac);
				if(pacienteUs!=null){
					var valUsAten=0;
					for(var w=0;w<pacientesMesAten.length;w++){
						if(pacientesMesAten[w].tipoidRegPac==pacienteUs.tipoidRegPac && pacientesMesAten[w].idRegPac==pacienteUs.idRegPac){
							valUsAten=1;
						}
					}
					
					if(valUsAten==0){
						pacientesMesAten.push(pacienteUs);
					
						cantUS=cantUS+1;
						var pnombre = '';
						var snombre = ''; 
						var eadp = (pacienteUs.eapb == null) ? '' : pacienteUs.eapb;
						var nombrsplit = pacienteUs.nombres.split(' ');
	
						if (nombrsplit.length <= 2) {
							pnombre = nombrsplit[0];
							snombre = nombrsplit[1];
						} else {
		
							pnombre = nombrsplit[0];
							for (var rti = 1; rti < nombrsplit.length; rti++) {
								snombre += nombrsplit[rti] + ' ';
							}
						}
						var edadSplit = calcularEdadReporte(pacienteUs.fecNac).split(' ');
					
						var eda = (edadSplit[1] == 'AÑOS') ? 1 : (edadSplit[1] == 'MESES') ? 2 : 3;
						var dptoRee = (pacienteUs.dptoResidencia < 10) ? '0' + pacienteUs.dptoResidencia : pacienteUs.dptoResidencia;
						var mnpoRee = (pacienteUs.mnpoResidencia < 10) ? '0' + pacienteUs.mnpoResidencia : pacienteUs.mnpoResidencia;
					   
						var contentUS=pacienteUs.tipoidRegPac + ',' +
									pacienteUs.idRegPac + ',' +
									eadp + ',' +
									pacienteUs.regimen + ',' +
									pacienteUs.papellido + ',' +
									pacienteUs.sapellido + ',' +
									pnombre + ',' +
									snombre + ',' +
									edadSplit[0] + ',' +
									eda + ',' +
									pacienteUs.sexo + ',' +
									dptoRee + ',' +
									mnpoRee + ',' +
									pacienteUs.zonaResidencia + '\r\n';
	
						contUS+=contentUS;
	
					}
					//SE PROCEDE A CREAR EL ARCHIVO DE FACTURACION

					contAF+=ripscodprest+','+
							ripsnombrePres+','+
							ripstipoidPres+','+
							ripsnumidPres+','+
							cantAC+','+
							codificarFechaRIPS(nutricional[i].fechaConsulta) + ',' + 
							'01/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';

					if(ripsmesReporrtRipsUS=='02'){
						contAF+='28/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else if(ripsmesReporrtRipsUS=='01' || ripsmesReporrtRipsUS=='03' || ripsmesReporrtRipsUS=='05' || ripsmesReporrtRipsUS=='07' || ripsmesReporrtRipsUS=='08' || ripsmesReporrtRipsUS=='10' || ripsmesReporrtRipsUS=='12'){
						contAF+='31/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else{
						contAF+='30/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}
					contAF+=ripscodentPres+','+
							ripsnombrentPres+',,,,0,0,0,0\r\n';

					cantAF=cantAF+1;
				}else{
					nutricionalContnue='';
				}
					
	
				contAC+=nutricionalContnue;
				
			}
			
		}
	} 
	if (adulto.length > 0) {

		for (var i = 0; i < adulto.length; i++) {
			//datPaciente = buscarPacienteDatosRips(adulto[i].tipoid_pac, adulto[i].numid_pac);
			console.log(adulto[i].fechaConsulta);
			var valmes=adulto[i].fechaConsulta.split('-');
			console.log(valmes);
			if(parseInt(valmes[1])==parseInt(ripsmesReporrtRipsUS) && parseInt(valmes[2])==parseInt(ripsanoReporrtRipsUS)){
				console.log('iguales');
				cantAC = cantAC + 1;
				var adultoContnue= cantAC + ',' +
				ripscodprest + ',' +
				adulto[i].tipoid_pac + ',' +
				adulto[i].numid_pac + ',' +
				codificarFechaRIPS(adulto[i].fechaConsulta) + ',' + 
				',';
	
				adultoContnue += adulto[i].tipoConsulta + ',' +
									adulto[i].finalidadConsulta + ',' +
									adulto[i].causaExternaConsulta + ',';
				diagnostCon = decodificarGimmids(adulto[i].listadoCIEPa);
				 
				if(adulto[i].listadoCIEPa){
					if (diagnostCon.length == 1) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = '';
						diagrel2 = '';
						diagrel3 = '';
		
					} else if (diagnostCon.length == 2) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = '';
						diagrel3 = '';
		
		
					} else if (diagnostCon.length == 3) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = '';
		
					} else if (diagnostCon.length >= 4) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = diagnostCon[3][0];
		
					}
				}else{
					diagPrin = '';
					diagrel1 = '';
					diagrel2 = '';
					diagrel3 = '';
				}
				adultoContnue += diagPrin + ',' +
					diagrel1 + ',' +
					diagrel2 + ',' +
					diagrel3 + ',' +
					adulto[i].tipoDiagnosPrinc + ',' +
					'0,' +
					'0,' +
					'0\r\n'; 
				//procedemos a añadir al archivo US los datos del usuario
				var pacienteUs=buscarPacienteIdent(adulto[i].tipoid_pac, adulto[i].numid_pac);
				if(pacienteUs!=null){
					var valUsAten=0;
					for(var w=0;w<pacientesMesAten.length;w++){
						if(pacientesMesAten[w].tipoidRegPac==pacienteUs.tipoidRegPac && pacientesMesAten[w].idRegPac==pacienteUs.idRegPac){
							valUsAten=1;
						}
					}
					
					if(valUsAten==0){
						pacientesMesAten.push(pacienteUs);
						cantUS=cantUS+1;
					
						var pnombre = '';
						var snombre = ''; 
						var eadp = (pacienteUs.eapb == null) ? '' : pacienteUs.eapb;
						var nombrsplit = pacienteUs.nombres.split(' ');
	
						if (nombrsplit.length <= 2) {
							pnombre = nombrsplit[0];
							snombre = nombrsplit[1];
						} else {
		
							pnombre = nombrsplit[0];
							for (var rti = 1; rti < nombrsplit.length; rti++) {
								snombre += nombrsplit[rti] + ' ';
							}
						}
						var edadSplit = calcularEdadReporte(pacienteUs.fecNac).split(' ');
					
						var eda = (edadSplit[1] == 'AÑOS') ? 1 : (edadSplit[1] == 'MESES') ? 2 : 3;
						var dptoRee = (pacienteUs.dptoResidencia < 10) ? '0' + pacienteUs.dptoResidencia : pacienteUs.dptoResidencia;
						var mnpoRee = (pacienteUs.mnpoResidencia < 10) ? '0' + pacienteUs.mnpoResidencia : pacienteUs.mnpoResidencia;
					   
						var contentUS=pacienteUs.tipoidRegPac + ',' +
									pacienteUs.idRegPac + ',' +
									eadp + ',' +
									pacienteUs.regimen + ',' +
									pacienteUs.papellido + ',' +
									pacienteUs.sapellido + ',' +
									pnombre + ',' +
									snombre + ',' +
									edadSplit[0] + ',' +
									eda + ',' +
									pacienteUs.sexo + ',' +
									dptoRee + ',' +
									mnpoRee + ',' +
									pacienteUs.zonaResidencia + '\r\n';
	
						contUS+=contentUS;
	
					}
					//SE PROCEDE A CREAR EL ARCHIVO DE FACTURACION

					contAF+=ripscodprest+','+
							ripsnombrePres+','+
							ripstipoidPres+','+
							ripsnumidPres+','+
							cantAC+','+
							codificarFechaRIPS(adulto[i].fechaConsulta) + ',' + 
							'01/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';

					if(ripsmesReporrtRipsUS=='02'){
						contAF+='28/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else if(ripsmesReporrtRipsUS=='01' || ripsmesReporrtRipsUS=='03' || ripsmesReporrtRipsUS=='05' || ripsmesReporrtRipsUS=='07' || ripsmesReporrtRipsUS=='08' || ripsmesReporrtRipsUS=='10' || ripsmesReporrtRipsUS=='12'){
						contAF+='31/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else{
						contAF+='30/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}
					contAF+=ripscodentPres+','+
							ripsnombrentPres+',,,,0,0,0,0\r\n';

					cantAF=cantAF+1;
				}else{
					adultoContnue='';
				}
					
	
				contAC+=adultoContnue;
				
			}
			
		}
	} 
	if (menor.length > 0) {

		for (var i = 0; i < menor.length; i++) {
			//datPaciente = buscarPacienteDatosRips(menor[i].tipoid_pac, menor[i].numid_pac);
			console.log(menor[i].fechaConsulta);
			var valmes=menor[i].fechaConsulta.split('-');
			console.log(valmes);
			if(valmes[1]==ripsmesReporrtRipsUS && valmes[2]==ripsanoReporrtRipsUS){
				console.log('iguales');
				cantAC = cantAC + 1;
				var menorContnue= cantAC + ',' +
				ripscodprest + ',' +
				menor[i].tipoid_pac + ',' +
				menor[i].numid_pac + ',' +
				codificarFechaRIPS(menor[i].fechaConsulta) + ',' + 
				',';
	
				menorContnue += menor[i].tipoConsulta + ',' +
									menor[i].finalidadConsulta + ',' +
									menor[i].causaExternaConsulta + ',';
				diagnostCon = decodificarGimmids(menor[i].listadoCIEPa);
				 
				if(menor[i].listadoCIEPa){
					if (diagnostCon.length == 1) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = '';
						diagrel2 = '';
						diagrel3 = '';
		
					} else if (diagnostCon.length == 2) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = '';
						diagrel3 = '';
		
		
					} else if (diagnostCon.length == 3) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = '';
		
					} else if (diagnostCon.length >= 4) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = diagnostCon[3][0];
		
					}
				}else{
					diagPrin = '';
					diagrel1 = '';
					diagrel2 = '';
					diagrel3 = '';
				}
				menorContnue += diagPrin + ',' +
					diagrel1 + ',' +
					diagrel2 + ',' +
					diagrel3 + ',' +
					menor[i].tipoDiagnosPrinc + ',' +
					'0,' +
					'0,' +
					'0\r\n'; 
				//procedemos a añadir al archivo US los datos del usuario
				var pacienteUs=buscarPacienteIdent(menor[i].tipoid_pac, menor[i].numid_pac);
				if(pacienteUs!=null){
					var valUsAten=0;
					for(var w=0;w<pacientesMesAten.length;w++){
						if(pacientesMesAten[w].tipoidRegPac==pacienteUs.tipoidRegPac && pacientesMesAten[w].idRegPac==pacienteUs.idRegPac){
							valUsAten=1;
						}
					}
					
					if(valUsAten==0){
						pacientesMesAten.push(pacienteUs);
						cantUS=cantUS+1;
					
						var pnombre = '';
						var snombre = ''; 
						var eadp = (pacienteUs.eapb == null) ? '' : pacienteUs.eapb;
						var nombrsplit = pacienteUs.nombres.split(' ');
	
						if (nombrsplit.length <= 2) {
							pnombre = nombrsplit[0];
							snombre = nombrsplit[1];
						} else {
		
							pnombre = nombrsplit[0];
							for (var rti = 1; rti < nombrsplit.length; rti++) {
								snombre += nombrsplit[rti] + ' ';
							}
						}
						var edadSplit = calcularEdadReporte(pacienteUs.fecNac).split(' ');
					
						var eda = (edadSplit[1] == 'AÑOS') ? 1 : (edadSplit[1] == 'MESES') ? 2 : 3;
						var dptoRee = (pacienteUs.dptoResidencia < 10) ? '0' + pacienteUs.dptoResidencia : pacienteUs.dptoResidencia;
						var mnpoRee = (pacienteUs.mnpoResidencia < 10) ? '0' + pacienteUs.mnpoResidencia : pacienteUs.mnpoResidencia;
					   
						var contentUS=pacienteUs.tipoidRegPac + ',' +
									pacienteUs.idRegPac + ',' +
									eadp + ',' +
									pacienteUs.regimen + ',' +
									pacienteUs.papellido + ',' +
									pacienteUs.sapellido + ',' +
									pnombre + ',' +
									snombre + ',' +
									edadSplit[0] + ',' +
									eda + ',' +
									pacienteUs.sexo + ',' +
									dptoRee + ',' +
									mnpoRee + ',' +
									pacienteUs.zonaResidencia + '\r\n';
	
						contUS+=contentUS;
	
					}
					//SE PROCEDE A CREAR EL ARCHIVO DE FACTURACION

					contAF+=ripscodprest+','+
							ripsnombrePres+','+
							ripstipoidPres+','+
							ripsnumidPres+','+
							cantAC+','+
							codificarFechaRIPS(menor[i].fechaConsulta) + ',' + 
							'01/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';

					if(ripsmesReporrtRipsUS=='02'){
						contAF+='28/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else if(ripsmesReporrtRipsUS=='01' || ripsmesReporrtRipsUS=='03' || ripsmesReporrtRipsUS=='05' || ripsmesReporrtRipsUS=='07' || ripsmesReporrtRipsUS=='08' || ripsmesReporrtRipsUS=='10' || ripsmesReporrtRipsUS=='12'){
						contAF+='31/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else{
						contAF+='30/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}
					contAF+=ripscodentPres+','+
							ripsnombrentPres+',,,,0,0,0,0\r\n';

					cantAF=cantAF+1;
				}else{
					menorContnue='';
				}
					
	
				contAC+=menorContnue;
				
			}
			
		}
	} 
	if (gestante.length > 0) {

		for (var i = 0; i < gestante.length; i++) {
			//datPaciente = buscarPacienteDatosRips(gestante[i].tipoid_pac, gestante[i].numid_pac);
			console.log(gestante[i].fechaConsulta);
			var valmes=gestante[i].fechaConsulta.split('-');
			console.log(valmes);
			if(valmes[1]==ripsmesReporrtRipsUS && valmes[2]==ripsanoReporrtRipsUS){
				console.log('iguales');
				cantAC = cantAC + 1;
				var gestanteContnue= cantAC + ',' +
				ripscodprest + ',' +
				gestante[i].tipoid_pac + ',' +
				gestante[i].numid_pac + ',' +
				codificarFechaRIPS(gestante[i].fechaConsulta) + ',' + 
				',';
	
				gestanteContnue += gestante[i].tipoConsulta + ',' +
									gestante[i].finalidadConsulta + ',' +
									gestante[i].causaExternaConsulta + ',';
				diagnostCon = decodificarGimmids(gestante[i].listadoCIEPa);
				 
				if(gestante[i].listadoCIEPa){
					if (diagnostCon.length == 1) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = '';
						diagrel2 = '';
						diagrel3 = '';
		
					} else if (diagnostCon.length == 2) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = '';
						diagrel3 = '';
		
		
					} else if (diagnostCon.length == 3) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = '';
		
					} else if (diagnostCon.length >= 4) {
						diagPrin = diagnostCon[0][0];
						diagrel1 = diagnostCon[1][0];
						diagrel2 = diagnostCon[2][0];
						diagrel3 = diagnostCon[3][0];
		
					}
				}else{
					diagPrin = '';
					diagrel1 = '';
					diagrel2 = '';
					diagrel3 = '';
				}
				gestanteContnue += diagPrin + ',' +
					diagrel1 + ',' +
					diagrel2 + ',' +
					diagrel3 + ',' +
					gestante[i].tipoDiagnosPrinc + ',' +
					'0,' +
					'0,' +
					'0\r\n'; 
				//procedemos a añadir al archivo US los datos del usuario
				var pacienteUs=buscarPacienteIdent(gestante[i].tipoid_pac, gestante[i].numid_pac);
				if(pacienteUs!=null){
					var valUsAten=0;
					for(var w=0;w<pacientesMesAten.length;w++){
						if(pacientesMesAten[w].tipoidRegPac==pacienteUs.tipoidRegPac && pacientesMesAten[w].idRegPac==pacienteUs.idRegPac){
							valUsAten=1;
						}
					}
					
					if(valUsAten==0){
						pacientesMesAten.push(pacienteUs);
						cantUS=cantUS+1;
					
						var pnombre = '';
						var snombre = ''; 
						var eadp = (pacienteUs.eapb == null) ? '' : pacienteUs.eapb;
						var nombrsplit = pacienteUs.nombres.split(' ');
	
						if (nombrsplit.length <= 2) {
							pnombre = nombrsplit[0];
							snombre = nombrsplit[1];
						} else {
		
							pnombre = nombrsplit[0];
							for (var rti = 1; rti < nombrsplit.length; rti++) {
								snombre += nombrsplit[rti] + ' ';
							}
						}
						var edadSplit = calcularEdadReporte(pacienteUs.fecNac).split(' ');
					
						var eda = (edadSplit[1] == 'AÑOS') ? 1 : (edadSplit[1] == 'MESES') ? 2 : 3;
						var dptoRee = (pacienteUs.dptoResidencia < 10) ? '0' + pacienteUs.dptoResidencia : pacienteUs.dptoResidencia;
						var mnpoRee = (pacienteUs.mnpoResidencia < 10) ? '0' + pacienteUs.mnpoResidencia : pacienteUs.mnpoResidencia;
					   
						var contentUS=pacienteUs.tipoidRegPac + ',' +
									pacienteUs.idRegPac + ',' +
									eadp + ',' +
									pacienteUs.regimen + ',' +
									pacienteUs.papellido + ',' +
									pacienteUs.sapellido + ',' +
									pnombre + ',' +
									snombre + ',' +
									edadSplit[0] + ',' +
									eda + ',' +
									pacienteUs.sexo + ',' +
									dptoRee + ',' +
									mnpoRee + ',' +
									pacienteUs.zonaResidencia + '\r\n';
	
						contUS+=contentUS;
	
					}
					//SE PROCEDE A CREAR EL ARCHIVO DE FACTURACION

					contAF+=ripscodprest+','+
							ripsnombrePres+','+
							ripstipoidPres+','+
							ripsnumidPres+','+
							cantAC+','+
							codificarFechaRIPS(gestante[i].fechaConsulta) + ',' + 
							'01/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';

					if(ripsmesReporrtRipsUS=='02'){
						contAF+='28/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else if(ripsmesReporrtRipsUS=='01' || ripsmesReporrtRipsUS=='03' || ripsmesReporrtRipsUS=='05' || ripsmesReporrtRipsUS=='07' || ripsmesReporrtRipsUS=='08' || ripsmesReporrtRipsUS=='10' || ripsmesReporrtRipsUS=='12'){
						contAF+='31/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else{
						contAF+='30/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}
					contAF+=ripscodentPres+','+
							ripsnombrentPres+',,,,0,0,0,0\r\n';
					cantAF=cantAF+1;

				}else{
					gestanteContnue='';
				}
					
	
				contAC+=gestanteContnue;
				
			}
			
		}
	} 

	if (procedimientos.length > 0) {

		for (var i = 0; i < procedimientos.length; i++) {
			//datPaciente = buscarPacienteDatosRips(procedimientos[i].tipodocupacie, procedimientos[i].numDocpPaci);
			console.log(procedimientos[i].fechaProce);
			var valmes=procedimientos[i].fechaProce.split('-');
			console.log(valmes);
			if(valmes[1]==ripsmesReporrtRipsUS && valmes[2]==ripsanoReporrtRipsUS){
				console.log('iguales'); 
				cantAC = cantAC + 1;
				var procedimientosContnue= cantAC + ',' +
										ripscodprest + ',' +
										procedimientos[i].tipodocupacie + ',' +
										procedimientos[i].numDocpPaci + ',' +
										codificarFechaRIPS(procedimientos[i].fechaProce) + ',' + 
										',';
	
			 	proceReali = decodificarGimmids(procedimientos[i].ordenesIngCon);
				 if(procedimientos[i].ordenesIngCon!=''){
					if (proceReali.length > 0) {
						procedimientosContnue+= proceReali[0][0]+',';
						 
		
					}else{
						procedimientosContnue+= ',';
						
					}

				}else{
					procedimientosContnue+= ',';
					
				}
				procedimientosContnue += procedimientos[i].AmbreaProc + ',' +
										procedimientos[i].FinaProc + ',' ;
				if(procedimientos[i].perfilPersonat){
					var perfilPaPro=procedimientos[i].perfilPersonat.split(' - ');
					procedimientosContnue+=perfilPaPro[0] + ',';
	
				}else{
					
					procedimientosContnue+=',';

				}
				

				dxproce = decodificarGimmids(procedimientos[i].cieIngCon);
				if(procedimientos[i].cieIngCon!=''){
					if (dxproce.length == 1) {
						dxPrin = dxproce[0][0];
						dxrel1 = ''; 
		
					} else if (dxproce.length == 2) {
						dxPrin = dxproce[0][0];
						dxrel1 = dxproce[1][0]; 
		
		
					} else{
						dxPrin = '';
						dxrel1 = ''; 
		
					}
				}else{
					dxPrin = '';
					dxrel1 = ''; 
	
				}
			
				procedimientosContnue+=dxPrin+','+
										dxrel1+',';
				
				complProce = decodificarGimmids(procedimientos[i].cieIngConComp);
				 
				if(procedimientos[i].cieIngConComp!=''){
					if(complProce.length>0){
						procedimientosContnue+=complProce[0][0]+',';
					}else{
	
						procedimientosContnue+=',';
					}
					console.log('no vacio');
				}else{
					
			 
					procedimientosContnue+=',';
				 
					console.log('vacio');
				}
				
				procedimientosContnue+=procedimientos[i].formReaAcQ + ',' +
										'0\r\n'; 
				//procedemos a añadir al archivo US los datos del usuario
				var pacienteUs=buscarPacienteIdent(procedimientos[i].tipodocupacie, procedimientos[i].numDocpPaci);
				if(pacienteUs!=null){
					var valUsAten=0;
					for(var w=0;w<pacientesMesAten.length;w++){
						if(pacientesMesAten[w].tipoidRegPac==pacienteUs.tipoidRegPac && pacientesMesAten[w].idRegPac==pacienteUs.idRegPac){
							valUsAten=1;
						}
					}
					
					if(valUsAten==0){
						pacientesMesAten.push(pacienteUs);
						cantUS=cantUS+1;
					
						var pnombre = '';
						var snombre = ''; 
						var eadp = (pacienteUs.eapb == null) ? '' : pacienteUs.eapb;
						var nombrsplit = pacienteUs.nombres.split(' ');
	
						if (nombrsplit.length <= 2) {
							pnombre = nombrsplit[0];
							snombre = nombrsplit[1];
						} else {
		
							pnombre = nombrsplit[0];
							for (var rti = 1; rti < nombrsplit.length; rti++) {
								snombre += nombrsplit[rti] + ' ';
							}
						}
						var edadSplit = calcularEdadReporte(pacienteUs.fecNac).split(' ');
					
						var eda = (edadSplit[1] == 'AÑOS') ? 1 : (edadSplit[1] == 'MESES') ? 2 : 3;
						var dptoRee = (pacienteUs.dptoResidencia < 10) ? '0' + pacienteUs.dptoResidencia : pacienteUs.dptoResidencia;
						var mnpoRee = (pacienteUs.mnpoResidencia < 10) ? '0' + pacienteUs.mnpoResidencia : pacienteUs.mnpoResidencia;
					   
						var contentUS=pacienteUs.tipoidRegPac + ',' +
									pacienteUs.idRegPac + ',' +
									eadp + ',' +
									pacienteUs.regimen + ',' +
									pacienteUs.papellido + ',' +
									pacienteUs.sapellido + ',' +
									pnombre + ',' +
									snombre + ',' +
									edadSplit[0] + ',' +
									eda + ',' +
									pacienteUs.sexo + ',' +
									dptoRee + ',' +
									mnpoRee + ',' +
									pacienteUs.zonaResidencia + '\r\n';
	
						contUS+=contentUS;
	
					}
					//SE PROCEDE A CREAR EL ARCHIVO DE FACTURACION

					contAF+=ripscodprest+','+
							ripsnombrePres+','+
							ripstipoidPres+','+
							ripsnumidPres+','+
							cantAC+','+
							codificarFechaRIPS(procedimientos[i].fechaProce) + ',' + 
							'01/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';

					if(ripsmesReporrtRipsUS=='02'){
						contAF+='28/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else if(ripsmesReporrtRipsUS=='01' || ripsmesReporrtRipsUS=='03' || ripsmesReporrtRipsUS=='05' || ripsmesReporrtRipsUS=='07' || ripsmesReporrtRipsUS=='08' || ripsmesReporrtRipsUS=='10' || ripsmesReporrtRipsUS=='12'){
						contAF+='31/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}else{
						contAF+='30/'+ripsmesReporrtRipsUS+'/'+ripsanoReporrtRipsUS+',';
					}
					contAF+=ripscodentPres+','+
							ripsnombrentPres+',,,,0,0,0,0\r\n';
					
					cantAF=cantAF+1;

				}else{
					procedimientosContnue='';
				}
					
				
				contAP+=procedimientosContnue;
				
			}
			
		}
	} 



	console.log(path);
	//path = path[0] + '\\AC' + $("#mesReporrtRipsUS").val() + '' + $("#anoReporrtRipsUS").val() + '.txt';
	console.log(path);
	var f = new Date();
	var mes=(f.getMonth() +1);
	console.log(mes);
	if(parseInt(mes)>=10){
		fechaCT=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
	
	}else{
		fechaCT=f.getDate() + "/" + "0"+(f.getMonth() +1) + "/" + f.getFullYear();
	
	}
	 
	contCT+=ripscodprest+','+
			fechaCT+','+
			'AC' + $("#mesReporrtRipsUS").val() + '' + $("#anoReporrtRipsUS").val()+','+
			cantAC+'\r\n';
	contCT+=ripscodprest+','+
			fechaCT+','+
			'AP' + $("#mesReporrtRipsUS").val() + '' + $("#anoReporrtRipsUS").val()+','+
			cantAP+'\r\n';
	contCT+=ripscodprest+','+
			fechaCT+','+
			'AF' + $("#mesReporrtRipsUS").val() + '' + $("#anoReporrtRipsUS").val()+','+
			cantAF+'\r\n';
	contCT+=ripscodprest+','+
			fechaCT+','+
			'US' + $("#mesReporrtRipsUS").val() + '' + $("#anoReporrtRipsUS").val()+','+
			cantUS+'\r\n';
	fs.writeFile(path[0] + '\\AC' + $("#mesReporrtRipsUS").val() + '' + $("#anoReporrtRipsUS").val() + '.txt', contAC, (err) => {
		if (err) {
			ipc.send('error', 'Error al generar archivo');
			location.reload();
		} else {
			ipc.send('info', 'Archivo generado Correctamente');
			//location.reload();
		}
	});
	fs.writeFile( path[0] + '\\AP' + $("#mesReporrtRipsUS").val() + '' + $("#anoReporrtRipsUS").val() + '.txt', contAP, (err) => {
		if (err) {
			ipc.send('error', 'Error al generar archivo');
			location.reload();
		} else {
			ipc.send('info', 'Archivo generado Correctamente');
			//location.reload();
		}
	});
	fs.writeFile( path[0] + '\\AF' + $("#mesReporrtRipsUS").val() + '' + $("#anoReporrtRipsUS").val() + '.txt', contAF, (err) => {
		if (err) {
			ipc.send('error', 'Error al generar archivo');
			location.reload();
		} else {
			ipc.send('info', 'Archivo generado Correctamente');
			//location.reload();
		}
	});
	fs.writeFile( path[0] + '\\US' + $("#mesReporrtRipsUS").val() + '' + $("#anoReporrtRipsUS").val() + '.txt', contUS, (err) => {
		if (err) {
			ipc.send('error', 'Error al generar archivo');
			location.reload();
		} else {
			ipc.send('info', 'Archivo generado Correctamente');
			//location.reload();
		}
	});
	fs.writeFile( path[0] + '\\CT' + $("#mesReporrtRipsUS").val() + '' + $("#anoReporrtRipsUS").val() + '.txt', contCT, (err) => {
		if (err) {
			ipc.send('error', 'Error al generar archivo');
			location.reload();
		} else {
			ipc.send('info', 'Archivo generado Correctamente');
			//location.reload();
		}
	});
	//crearRipstTXTU(path);

});

function decodificarGimmids(data) {
	var arra = data.split('   -   ');
	var dat = []
	for (var t = 0; t < arra.length - 1; t++) {
		dat.push(arra[t].split('-,-'));

	}
	return dat;
}
function codificarFechaRIPS(fecha){
	fecha=fecha.split('-'); 
	return fecha[2]+'/'+fecha[1]+'/'+fecha[0];
}
function buscarPacienteIdent(tipoid, numid){
	for(var e=0;e<pacientes.length;e++){
		if(pacientes[e].idRegPac==numid && pacientes[e].tipoidRegPac==tipoid){
			return pacientes[e];
		}
	}
	return null;
}
 

function calcularEdadReporte(fec) {
	console.log(fec);
	var fechaCalculada = calculaEdadRipsUS(fec);
	console.log(fechaCalculada);
	if (fechaCalculada.anos > 0) {
		return fechaCalculada.anos + ' AÑOS';

	} else {
		return fechaCalculada.meses + ' MESES';

	}
}
function calculaEdadRipsUS(fec){
	var nacimiento = fec;
	var values = nacimiento.split("-");

	var dia = values[2];
	var mes = values[1];
	var ano = values[0];

	// cogemos los valores actuales
	var fecha_hoy = new Date();
	var ahora_ano = fecha_hoy.getYear();
	var ahora_mes = fecha_hoy.getMonth() + 1;
	var ahora_dia = fecha_hoy.getDate();

	// realizamos el calculo
	var edad = (ahora_ano + 1900) - ano;
	if (ahora_mes < mes) {
		edad--;
	}
	if ((mes == ahora_mes) && (ahora_dia < dia)) {
		edad--;
	}
	if (edad > 1900) {
		edad -= 1900;
	}

	// calculamos los meses
	var meses = 0;
	if (ahora_mes > mes)
		meses = ahora_mes - mes;
	if (ahora_mes < mes)
		meses = 12 - (mes - ahora_mes);
	if (ahora_mes == mes && dia > ahora_dia)
		meses = 11;

	// calculamos los dias
	var dias = 0;
	if (ahora_dia > dia)
		dias = ahora_dia - dia;
	if (ahora_dia < dia) {
		var ultimoDiaMes = new Date(ahora_ano, ahora_mes, 0);
		dias = ultimoDiaMes.getDate() - (dia - ahora_dia);
	}


	//if(edad<18 ){
	var dataRes = { 'anos': edad, 'meses': meses-1, 'dias': dias };
	return dataRes;
}


function abrirServidor(){
	
	$.post('https://api.gimmids.com/pruebas/servicios/listarPacientes.php',{'key':'GimmidsApp'}, function(data) {
		console.log(data);
		if (data.STATUS == 'OK') {
			if(data.DATA.length>0){
				var content='';
				listaPacientes=data.DATA;
				pacientesServidor=listaPacientes;
				for (var i = 0; i < listaPacientes.length; i++) {
					content += '<tr   >'
								+'<td >' + listaPacientes[i].tipoidRegPac + '</td>'
								+'<td >' + listaPacientes[i].idRegPac + '</td>'
								+'<td >' + listaPacientes[i].otroDocumRep + '</td>'
								+'<td >' + listaPacientes[i].nombres + ' ' + listaPacientes[i].papellido + ' ' + listaPacientes[i].sapellido + '</td>'
								+'<td >' + listaPacientes[i].estCivil + '</td>'
								+'<td >' + listaPacientes[i].sexo + '</td>'
								+'<td >' + listaPacientes[i].fecNac + '</td>'
								+'<td >' + listaPacientes[i].status_migratorio + '</td>'
								+'<td >' + listaPacientes[i].tipoPoblacion + '</td>'
								+'<td >' + listaPacientes[i].perfilPacie + '</td>'
								+'<td >' + listaPacientes[i].movilidadPacie + '</td>'
								+'<td >' + listaPacientes[i].telefono + '</td>'
								+'<td >' + listaPacientes[i].direccionResidencia + '</td>'
								+'<td >' + listaPacientes[i].zonaResidencia + '</td>'
								+'<td >' + listadoseleccionPais(listaPacientes[i].paisProcedencia) + '</td>'
								+'<td >' + listadoseleccionDpto(listaPacientes[i].paisProcedencia,listaPacientes[i].dptoProcedencia) + '</td>'
								+'<td >' + listadoseleccionMnpo(listaPacientes[i].paisProcedencia,listaPacientes[i].dptoProcedencia,listaPacientes[i].mnpoProcedencia) + '</td>' 
								+'<td >' + listaPacientes[i].BDUA + '</td>'
								+'<td >' + listadoseleccionEAPB(listaPacientes[i].eapb) + '</td>'
								+'<td >' + listaPacientes[i].tiemrpoingresoColo + '</td>'
								+'<td >' + listadoseleccionReg(listaPacientes[i].regimen) + '</td>'
								+'<td >' + listadoseleccionEtnia(listaPacientes[i].perEtnica) + '</td>'
								+'<td >' + listaPacientes[i].correoElec + '</td>'
								+'<td >' + listaPacientes[i].fecha_registro + '</td>'
	
					+'</tr>';
				}
				$("#listadoPacientesServerTablaBody").html(content);
				
				$('#listadoPacientesServerTabla').dataTable();
			}
		} else {
	
			
		}
	}, "JSON" ).fail(function(data) {
		console.log(data);
		alert("error: " + data); 
	}, "JSON");
	var contConsultas='';
	$.ajax({
		url: "https://api.gimmids.com/pruebas/servicios/listarConsultasGenerales.php",
		type: "post",
		dataType: "html",
		data: {'inst': usuario.institucion, 'key':'GimmidsApp'},
		async:false
	}).done(function(res){ 
		console.log(res);
		data2=JSON.parse(res); 
		console.log(data2);
		generalServidor=data2;
		for(var t=0;t<data2.DATA.length;t++){
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirServer(`'+t+'`,`general`)">'+
						'<td>GENERAL</td>'+
						'<td>'+data2.DATA[t].fechaConsulta+'</td> '+
						'<td>'+data2.DATA[t].nombres+' '+data2.DATA[t].papellido+' '+data2.DATA[t].sapellido+'</td>'+
						'<td>'+data2.DATA[t].tipoid_pac+'</td>'+
						'<td>'+data2.DATA[t].numid_pac+'</td>'+
						'<td>'+data2.DATA[t].motivoConsulta+'</td>'+
						'<td>'+data2.DATA[t].tipoConsulta+'</td>'+
						'<td>'+data2.DATA[t].finalidadConsulta+'</td> '+
						'<td>'+data2.DATA[t].causaExternaConsulta+'</td>';

			contConsultas +='<td>';
			if(data2.DATA[t].listadoCIEPa!=''){
			tddiagnostConsultasPacien = decodificarGimmids(data2.DATA[t].listadoCIEPa);

			for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
				contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+data2.DATA[t].tipoDiagnosPrinc+`</td> 
						<td>`+data2.DATA[t].profAtiende+`</td>  
					
					</tr>`;
		}
	}).fail(function(e) { 
		console.log(e);
		 alert('Error'+ e);
		
	});

	$.ajax({
		url: "https://api.gimmids.com/pruebas/servicios/listarConsultasEnfermeria.php",
		type: "post",
		dataType: "html",
		data: {'inst': usuario.institucion, 'key':'GimmidsApp'},
		async:false
	}).done(function(res){ 
		data2=JSON.parse(res); 
		console.log(data2);
		enfermeriaServidor=data2;
		for(var t=0;t<data2.DATA.length;t++){
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirServer(`'+t+'`,`enfermeria`)">'+
						'<td>ENFERMERIA</td>'+
						'<td>'+data2.DATA[t].fechaConsulta+'</td> '+
						'<td>'+data2.DATA[t].nombres+' '+data2.DATA[t].papellido+' '+data2.DATA[t].sapellido+'</td>'+
						'<td>'+data2.DATA[t].tipoid_pac+'</td>'+
						'<td>'+data2.DATA[t].numid_pac+'</td>'+
						'<td>'+data2.DATA[t].motivoConsulta+'</td>'+
						'<td>'+data2.DATA[t].tipoConsulta+'</td>'+
						'<td>'+data2.DATA[t].finalidadConsulta+'</td> '+
						'<td>'+data2.DATA[t].causaExternaConsulta+'</td>';

			contConsultas +='<td>';
			if(data2.DATA[t].listadoCIEPa!=''){
			tddiagnostConsultasPacien = decodificarGimmids(data2.DATA[t].listadoCIEPa);

			for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
				contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+data2.DATA[t].tipoDiagnosPrinc+`</td> 
						<td>`+data2.DATA[t].profAtiende+`</td>  
					
					</tr>`;
		}
	}).fail(function(e) { 
		console.log(e);
		 alert('Error'+ e);
		
	});
	$.ajax({
		url: "https://api.gimmids.com/pruebas/servicios/listarConsultasPsicologia.php",
		type: "post",
		dataType: "html",
		data: {'inst': usuario.institucion, 'key':'GimmidsApp'},
		async:false
	}).done(function(res){ 
		data2=JSON.parse(res); 
		console.log(data2);
		psicologiaServidor=data2;
		for(var t=0;t<data2.DATA.length;t++){
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirServer(`'+t+'`,`psicologia`)">'+
						'<td>PSICOLOGIA</td>'+
						'<td>'+data2.DATA[t].fechaConsulta+'</td> '+
						'<td>'+data2.DATA[t].nombres+' '+data2.DATA[t].papellido+' '+data2.DATA[t].sapellido+'</td>'+
						'<td>'+data2.DATA[t].tipoid_pac+'</td>'+
						'<td>'+data2.DATA[t].numid_pac+'</td>'+
						'<td>'+data2.DATA[t].motivoConsulta+'</td>'+
						'<td>'+data2.DATA[t].tipoConsulta+'</td>'+
						'<td>'+data2.DATA[t].finalidadConsulta+'</td> '+
						'<td>'+data2.DATA[t].causaExternaConsulta+'</td>';

			contConsultas +='<td>';
			if(data2.DATA[t].listadoCIEPa!=''){
			tddiagnostConsultasPacien = decodificarGimmids(data2.DATA[t].listadoCIEPa);

			for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
				contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+data2.DATA[t].tipoDiagnosPrinc+`</td> 
						<td>`+data2.DATA[t].profAtiende+`</td>  
					
					</tr>`;
		}
	}).fail(function(e) { 
		console.log(e);
		 alert('Error'+ e);
		
	});
	$.ajax({
		url: "https://api.gimmids.com/pruebas/servicios/listarConsultasNutricional.php",
		type: "post",
		dataType: "html",
		data: {'inst': usuario.institucion, 'key':'GimmidsApp'},
		async:false
	}).done(function(res){ 
		data2=JSON.parse(res); 
		console.log(data2);
		nutricionalServidor=data2;
		for(var t=0;t<data2.DATA.length;t++){
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirServer(`'+t+'`,`nutricional`)">'+
						'<td>NUTRICIONAL</td>'+
						'<td>'+data2.DATA[t].fechaConsulta+'</td> '+
						'<td>'+data2.DATA[t].nombres+' '+data2.DATA[t].papellido+' '+data2.DATA[t].sapellido+'</td>'+
						'<td>'+data2.DATA[t].tipoid_pac+'</td>'+
						'<td>'+data2.DATA[t].numid_pac+'</td>'+
						'<td>'+data2.DATA[t].motivoConsulta+'</td>'+
						'<td>'+data2.DATA[t].tipoConsulta+'</td>'+
						'<td>'+data2.DATA[t].finalidadConsulta+'</td> '+
						'<td>'+data2.DATA[t].causaExternaConsulta+'</td>';

			contConsultas +='<td>';
			if(data2.DATA[t].listadoCIEPa!=''){
			tddiagnostConsultasPacien = decodificarGimmids(data2.DATA[t].listadoCIEPa);

			for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
				contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+data2.DATA[t].tipoDiagnosPrinc+`</td> 
						<td>`+data2.DATA[t].profAtiende+`</td>  
					
					</tr>`;
		}
	}).fail(function(e) { 
		console.log(e);
		 alert('Error'+ e);
		
	});


	$.ajax({
		url: "https://api.gimmids.com/pruebas/servicios/listarConsultasAdulto.php",
		type: "post",
		dataType: "html",
		data: {'inst': usuario.institucion, 'key':'GimmidsApp'},
		async:false
	}).done(function(res){ 
		data2=JSON.parse(res); 
		console.log(data2);
		adultoServidor=data2;
		for(var t=0;t<data2.DATA.length;t++){
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirServer(`'+t+'`,`adulto`)">'+
						'<td>ADULTO</td>'+
						'<td>'+data2.DATA[t].fechaConsulta+'</td> '+
						'<td>'+data2.DATA[t].nombres+' '+data2.DATA[t].papellido+' '+data2.DATA[t].sapellido+'</td>'+
						'<td>'+data2.DATA[t].tipoid_pac+'</td>'+
						'<td>'+data2.DATA[t].numid_pac+'</td>'+
						'<td>'+data2.DATA[t].motivoConsulta+'</td>'+
						'<td>'+data2.DATA[t].tipoConsulta+'</td>'+
						'<td>'+data2.DATA[t].finalidadConsulta+'</td> '+
						'<td>'+data2.DATA[t].causaExternaConsulta+'</td>';

			contConsultas +='<td>';
			if(data2.DATA[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(data2.DATA[t].listadoCIEPa);

				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+data2.DATA[t].tipoDiagnosPrinc+`</td> 
						<td>`+data2.DATA[t].profAtiende+`</td>  
					
					</tr>`;
		}
	}).fail(function(e) { 
		console.log(e);
		 alert('Error'+ e);
		
	});

	$.ajax({
		url: "https://api.gimmids.com/pruebas/servicios/listarConsultasMenor.php",
		type: "post",
		dataType: "html",
		data: {'inst': usuario.institucion, 'key':'GimmidsApp'},
		async:false
	}).done(function(res){ 
		data2=JSON.parse(res); 
		console.log(data2);
		menorServidor=data2;
		for(var t=0;t<data2.DATA.length;t++){
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirServer(`'+t+'`,`menor`)">'+
						'<td>MENOR</td>'+
						'<td>'+data2.DATA[t].fechaConsulta+'</td> '+
						'<td>'+data2.DATA[t].nombres+' '+data2.DATA[t].papellido+' '+data2.DATA[t].sapellido+'</td>'+
						'<td>'+data2.DATA[t].tipoid_pac+'</td>'+
						'<td>'+data2.DATA[t].numid_pac+'</td>'+
						'<td>'+data2.DATA[t].motivoConsulta+'</td>'+
						'<td>'+data2.DATA[t].tipoConsulta+'</td>'+
						'<td>'+data2.DATA[t].finalidadConsulta+'</td> '+
						'<td>'+data2.DATA[t].causaExternaConsulta+'</td>';

			contConsultas +='<td>';
			if(data2.DATA[t].listadoCIEPa!=''){
			tddiagnostConsultasPacien = decodificarGimmids(data2.DATA[t].listadoCIEPa);

			for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
				contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+data2.DATA[t].tipoDiagnosPrinc+`</td> 
						<td>`+data2.DATA[t].profAtiende+`</td>  
					
					</tr>`;
		}
	}).fail(function(e) { 
		console.log(e);
		 alert('Error'+ e);
		
	});
	$.ajax({
		url: "https://api.gimmids.com/pruebas/servicios/listarConsultasGestantes.php",
		type: "post",
		dataType: "html",
		data: {'inst': usuario.institucion, 'key':'GimmidsApp'},
		async:false
	}).done(function(res){ 
		data2=JSON.parse(res); 
		console.log(data2);
		gestanteServidor=data2;
		for(var t=0;t<data2.DATA.length;t++){
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirServer(`'+t+'`,`gestante`)">'+
						'<td>GESTANTE</td>'+
						'<td>'+data2.DATA[t].fechaConsulta+'</td> '+
						'<td>'+data2.DATA[t].nombres+' '+data2.DATA[t].papellido+' '+data2.DATA[t].sapellido+'</td>'+
						'<td>'+data2.DATA[t].tipoid_pac+'</td>'+
						'<td>'+data2.DATA[t].numid_pac+'</td>'+
						'<td>'+data2.DATA[t].motivoConsulta+'</td>'+
						'<td>'+data2.DATA[t].tipoConsulta+'</td>'+
						'<td>'+data2.DATA[t].finalidadConsulta+'</td> '+
						'<td>'+data2.DATA[t].causaExternaConsulta+'</td>';

			contConsultas +='<td>';
			if(data2.DATA[t].listadoCIEPa!=''){
			tddiagnostConsultasPacien = decodificarGimmids(data2.DATA[t].listadoCIEPa);

			for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
				contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+data2.DATA[t].tipoDiagnosPrinc+`</td> 
						<td>`+data2.DATA[t].profAtiende+`</td>  
					
					</tr>`;
		}
	}).fail(function(e) { 
		console.log(e);
		 alert('Error'+ e);
		
	});

	$("#listadoConsultassServerTablaBody").html(contConsultas);
	
	$('#listadoConsultassServerTabla').dataTable();

}

function abrirBases(){
	var contentbase='';
				 
	for (var i = 0; i < pacientes.length; i++) {
		contentbase += '<tr   >'
					+'<td >' + pacientes[i].tipoidRegPac + '</td>'
					+'<td >' + pacientes[i].idRegPac + '</td>'
					+'<td >' + pacientes[i].otroDocumRep + '</td>'
					+'<td >' + pacientes[i].nombres + ' ' + pacientes[i].papellido + ' ' + pacientes[i].sapellido + '</td>'
					+'<td >' + pacientes[i].estCivil + '</td>'
					+'<td >' + pacientes[i].sexo + '</td>'
					+'<td >' + pacientes[i].fecNac + '</td>'
					+'<td >' + pacientes[i].status_migratorio + '</td>'
					+'<td >' + pacientes[i].tipoPoblacion + '</td>'
					+'<td >' + pacientes[i].perfilPacie + '</td>'
					+'<td >' + pacientes[i].movilidadPacie + '</td>'
					+'<td >' + pacientes[i].telefono + '</td>'
					+'<td >' + pacientes[i].direccionResidencia + '</td>'
					+'<td >' + pacientes[i].zonaResidencia + '</td>'
					+'<td >' + listadoseleccionPais(pacientes[i].paisProcedencia) + '</td>'
					+'<td >' + listadoseleccionDpto(pacientes[i].paisProcedencia,pacientes[i].dptoProcedencia) + '</td>'
					+'<td >' + listadoseleccionMnpo(pacientes[i].paisProcedencia,pacientes[i].dptoProcedencia,pacientes[i].mnpoProcedencia) + '</td>' 
					+'<td >' + pacientes[i].BDUA + '</td>'
					+'<td >' + listadoseleccionEAPB(pacientes[i].eapb) + '</td>'
					+'<td >' + pacientes[i].tiemrpoingresoColo + '</td>'
					+'<td >' + listadoseleccionReg(pacientes[i].regimen) + '</td>'
					+'<td >' + listadoseleccionEtnia(pacientes[i].perEtnica) + '</td>'
					+'<td >' + pacientes[i].correoElec + '</td>'
					+'<td >' + pacientes[i].fecha_registro + '</td>'

		+'</tr>';
	}
	$("#listadoPacientesBaseTablaBody").html(contentbase);
	
	$('#listadoPacientesBaseTabla').dataTable(  {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );

	contConsultas='';
	for(var t=0;t<generales.length;t++){
		
		dataPAci=buscarPacienteIdent(generales[t].tipoid_pac, generales[t].numid_pac);
		if(dataPAci!=null){

			contConsultas+='<tr onclick="Javascript: verConsultaImprimirBase(`'+t+'`,`general`)">'+
								'<td>GENERAL</td>'+
								'<td>'+generales[t].fechaConsulta+'</td> '+
								'<td>'+dataPAci.nombres+' '+dataPAci.papellido+' '+dataPAci.sapellido+'</td>'+
								'<td>'+generales[t].tipoid_pac+'</td>'+
								'<td>'+generales[t].numid_pac+'</td>'+
								'<td>'+generales[t].motivoConsulta+'</td>'+
								'<td>'+generales[t].tipoConsulta+'</td>'+
								'<td>'+generales[t].finalidadConsulta+'</td> '+
								'<td>'+generales[t].causaExternaConsulta+'</td>';
			
			contConsultas +='<td>';
			if(generales[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(generales[t].listadoCIEPa);
			
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			
				}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+generales[t].tipoDiagnosPrinc+`</td> 
								<td>`+generales[t].profAtiende+`</td>  
							
							</tr>`;
		}

	}
	for(var t=0;t<enfermeria.length;t++){
		
		dataPAci=buscarPacienteIdent(enfermeria[t].tipoid_pac, enfermeria[t].numid_pac);
		if(dataPAci!=null){
	
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirBase(`'+t+'`,`enfermeria`)">'+
								'<td>ENFERMERIA</td>'+
								'<td>'+enfermeria[t].fechaConsulta+'</td> '+
								'<td>'+dataPAci.nombres+' '+dataPAci.papellido+' '+dataPAci.sapellido+'</td>'+
								'<td>'+enfermeria[t].tipoid_pac+'</td>'+
								'<td>'+enfermeria[t].numid_pac+'</td>'+
								'<td>'+enfermeria[t].motivoConsulta+'</td>'+
								'<td>'+enfermeria[t].tipoConsulta+'</td>'+
								'<td>'+enfermeria[t].finalidadConsulta+'</td> '+
								'<td>'+enfermeria[t].causaExternaConsulta+'</td>';
			
			contConsultas +='<td>';
			if(enfermeria[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(enfermeria[t].listadoCIEPa);
			
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			
				}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+enfermeria[t].tipoDiagnosPrinc+`</td> 
								<td>`+enfermeria[t].profAtiende+`</td>  
							
							</tr>`;
		}
	
	}
	for(var t=0;t<psicologia.length;t++){
		
		dataPAci=buscarPacienteIdent(psicologia[t].tipoid_pac, psicologia[t].numid_pac);
		if(dataPAci!=null){
	
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirBase(`'+t+'`,`psicologia`)">'+
								'<td>PSICOLOGIA</td>'+
								'<td>'+psicologia[t].fechaConsulta+'</td> '+
								'<td>'+dataPAci.nombres+' '+dataPAci.papellido+' '+dataPAci.sapellido+'</td>'+
								'<td>'+psicologia[t].tipoid_pac+'</td>'+
								'<td>'+psicologia[t].numid_pac+'</td>'+
								'<td>'+psicologia[t].motivoConsulta+'</td>'+
								'<td>'+psicologia[t].tipoConsulta+'</td>'+
								'<td>'+psicologia[t].finalidadConsulta+'</td> '+
								'<td>'+psicologia[t].causaExternaConsulta+'</td>';
			
			contConsultas +='<td>';
			if(psicologia[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(psicologia[t].listadoCIEPa);
			
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			
				}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+psicologia[t].tipoDiagnosPrinc+`</td> 
								<td>`+psicologia[t].profAtiende+`</td>  
							
							</tr>`;
		}
	
	}

	for(var t=0;t<nutricional.length;t++){
		
		dataPAci=buscarPacienteIdent(nutricional[t].tipoid_pac, nutricional[t].numid_pac);
		if(dataPAci!=null){
	
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirBase(`'+t+'`,`nutricional`)">'+
								'<td>NUTRICIONAL</td>'+
								'<td>'+nutricional[t].fechaConsulta+'</td> '+
								'<td>'+dataPAci.nombres+' '+dataPAci.papellido+' '+dataPAci.sapellido+'</td>'+
								'<td>'+nutricional[t].tipoid_pac+'</td>'+
								'<td>'+nutricional[t].numid_pac+'</td>'+
								'<td>'+nutricional[t].motivoConsulta+'</td>'+
								'<td>'+nutricional[t].tipoConsulta+'</td>'+
								'<td>'+nutricional[t].finalidadConsulta+'</td> '+
								'<td>'+nutricional[t].causaExternaConsulta+'</td>';
			
			contConsultas +='<td>';
			if(nutricional[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(nutricional[t].listadoCIEPa);
			
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			
				}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+nutricional[t].tipoDiagnosPrinc+`</td> 
								<td>`+nutricional[t].profAtiende+`</td>  
							
							</tr>`;
		}
	
	}
	for(var t=0;t<menor.length;t++){
		
		dataPAci=buscarPacienteIdent(menor[t].tipoid_pac, menor[t].numid_pac);
		if(dataPAci!=null){
	
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirBase(`'+t+'`,`menor`)">'+
								'<td>MENOR</td>'+
								'<td>'+menor[t].fechaConsulta+'</td> '+
								'<td>'+dataPAci.nombres+' '+dataPAci.papellido+' '+dataPAci.sapellido+'</td>'+
								'<td>'+menor[t].tipoid_pac+'</td>'+
								'<td>'+menor[t].numid_pac+'</td>'+
								'<td>'+menor[t].motivoConsulta+'</td>'+
								'<td>'+menor[t].tipoConsulta+'</td>'+
								'<td>'+menor[t].finalidadConsulta+'</td> '+
								'<td>'+menor[t].causaExternaConsulta+'</td>';
			
			contConsultas +='<td>';
			if(menor[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(menor[t].listadoCIEPa);
			
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			
				}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+menor[t].tipoDiagnosPrinc+`</td> 
								<td>`+menor[t].profAtiende+`</td>  
							
							</tr>`;
		}
	
	}
	for(var t=0;t<adulto.length;t++){
		
		dataPAci=buscarPacienteIdent(adulto[t].tipoid_pac, adulto[t].numid_pac);
		if(dataPAci!=null){
	
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirBase(`'+t+'`,`adulto`)">'+
								'<td>ADULTO</td>'+
								'<td>'+adulto[t].fechaConsulta+'</td> '+
								'<td>'+dataPAci.nombres+' '+dataPAci.papellido+' '+dataPAci.sapellido+'</td>'+
								'<td>'+adulto[t].tipoid_pac+'</td>'+
								'<td>'+adulto[t].numid_pac+'</td>'+
								'<td>'+adulto[t].motivoConsulta+'</td>'+
								'<td>'+adulto[t].tipoConsulta+'</td>'+
								'<td>'+adulto[t].finalidadConsulta+'</td> '+
								'<td>'+adulto[t].causaExternaConsulta+'</td>';
			
			contConsultas +='<td>';
			if(adulto[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(adulto[t].listadoCIEPa);
			
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			
				}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+adulto[t].tipoDiagnosPrinc+`</td> 
								<td>`+adulto[t].profAtiende+`</td>  
							
							</tr>`;
		}
	
	}
	for(var t=0;t<gestante.length;t++){
		
		dataPAci=buscarPacienteIdent(gestante[t].tipoid_pac, gestante[t].numid_pac);
		if(dataPAci!=null){
	
			contConsultas+='<tr onclick="Javascript: verConsultaImprimirBase(`'+t+'`,`gestante`)">'+
								'<td>GESTANTE</td>'+
								'<td>'+gestante[t].fechaConsulta+'</td> '+
								'<td>'+dataPAci.nombres+' '+dataPAci.papellido+' '+dataPAci.sapellido+'</td>'+
								'<td>'+gestante[t].tipoid_pac+'</td>'+
								'<td>'+gestante[t].numid_pac+'</td>'+
								'<td>'+gestante[t].motivoConsulta+'</td>'+
								'<td>'+gestante[t].tipoConsulta+'</td>'+
								'<td>'+gestante[t].finalidadConsulta+'</td> '+
								'<td>'+gestante[t].causaExternaConsulta+'</td>';
			
			contConsultas +='<td>';
			if(gestante[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(gestante[t].listadoCIEPa);
			
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
			
				}
			}else{
				contConsultas +='SIN DX';
			}
			contConsultas +='</td>';
			contConsultas +=	`<td>`+gestante[t].tipoDiagnosPrinc+`</td> 
								<td>`+gestante[t].profAtiende+`</td>  
							
							</tr>`;
		}
	
	}
	$("#listadoConsultassBaseTablaBody").html(contConsultas);
	
	$('#listadoConsultassBaseTabla').dataTable();


}


function listadoseleccionPais(pais){
   
    for(var t=0;t<paises.length;t++){
        if(pais==paises[t].Id){ 
            return paises[t].nombre;
        }
    } 
}
function listadoseleccionDpto(pais, dpto){
  
    if(pais=='45'){
        for(var ty=0;ty<dptos.length;ty++){
            if(dpto==dptos[ty].Id){ 
                return dptos[ty].nombre;
            }
		}
    }else if(pais=='242'){

        for(var ty=0;ty<dptosv.length;ty++){
            if(dpto==dptosv[ty].Id){ 
                return dptosv[ty].nombre;
            }
		}
    }else{
        return dpto;
    }
}
function listadoseleccionMnpo(pais, dpto, mnpo){

    if(pais=='45'){
        for(var t=0;t<mnpos.length;t++){
            if(mnpos[t].cod_dptop==dpto && mnpos[t].cod_mnpo==mnpo){
                return mnpos[t].nombre_mnpo;
            }
        }
    }else{
        return mnpo;
    }

}
function listadoseleccionEAPB(eap){
    for(var t=0;t<eapb.length;t++){
        if(eap==eapb[t].Id){
            return eapb[t].nombre;
        }
    }
	return '';
}
function listadoseleccionReg(reg){
    if(reg=='1'){
        return 'Contributivo';
    }
    if(reg=='2'){
        return 'Subsidiadovar';
    }
    if(reg=='3'){
        return 'Vinculado';
    }
    if(reg=='4'){
        return 'Particular';
    }
    if(reg=='5'){
        return 'Otro';
    }
    if(reg=='6'){
        return 'Víctima con afiliación al Régimen Contributivo';
    }
    if(reg=='7'){
        return 'Víctima con afiliación al Régimen subsidiado';
    }
    if(reg=='8'){
        return 'Víctima no asegurado (Vinculado)';
    }
}
function listadoseleccionEtnia(etn){
    if(etn=='1'){
        return 'NEGRO, MULATO, AFROCOLOMBIANO';
    }
    if(etn=='2'){
        return 'PALENQUERO';
    }
    if(etn=='3'){
        return 'ROOM (GITANO)';
    }
    if(etn=='4'){
        return 'INDIGENA';
    }
    if(etn=='5'){
        return 'RAIZAL';
    }
    if(etn=='6'){
        return 'OTRO';
    } 
}
function listadoseleccionPuebloInd(pue){
    for(var t=0;t<puebloindigena.length;t++){
        if(pue==puebloindigena[t].Id){
            return puebloindigena[t].nombre;
        }
    }
}

function decodificarGimmids(data) {
	console.log(data);
	if (data != '') {
		if (data[0].length == 1) {
			var arra = data.split('   -   ');
			////console.log(arra);
			var dat = []
			for (var t = 0; t < arra.length; t++) {
				//console.log(arra[t]);
				dat.push(arra[t].split('-,-'));
				//console.log(dat);
			}

			return dat;

		} else {
			return data;
		}

	}
}

function verConsultaImprimirBase(index, tipo){
	console.log(index);
	if(tipo=='general'){
		
		console.log(generales[index]);
	
	}
	if(tipo=='enfermeria'){
		
		console.log(enfermeria[index]);
	
	}
	if(tipo=='psicologia'){
		
		console.log(psicologia[index]);
	
	}
	if(tipo=='nutricional'){
		
		console.log(nutricional[index]);
	
	}
	if(tipo=='menor'){
		
		console.log(menor[index]);
	
	}
	if(tipo=='adulto'){
		
		console.log(adulto[index]);
	
	}
	if(tipo=='gestante'){
		
		console.log(gestante[index]);
	
	}
}
function verConsultaImprimirServer(index, tipo){
	console.log(index);
	if(tipo=='general'){
		
		console.log(generales[index]);


	
	}
	if(tipo=='enfermeria'){
		
		console.log(enfermeria[index]);
	
	}
	if(tipo=='psicologia'){
		
		console.log(psicologia[index]);
	
	}
	if(tipo=='nutricional'){
		
		console.log(nutricional[index]);
	
	}
	if(tipo=='menor'){
		
		console.log(menor[index]);
	
	}
	if(tipo=='adulto'){
		
		console.log(adulto[index]);
	
	}
	if(tipo=='gestante'){
		
		console.log(gestante[index]);
	
	}
}
function atenderConsulta(id, tipodoc, doc, nombres, servicio){
	 
	if(confirm('Confirmas la atención?')){
		localStorage.setItem('entrada', 'agenda');
		localStorage.setItem('servicioAgendado', servicio);
		var val=0;
		for(var q=0;q<pacientes.length;q++){
			if(pacientes[q].tipoidRegPac==tipodoc && pacientes[q].idRegPac==doc && pacientes[q].nombres+' '+pacientes[q].papellido+' '+pacientes[q].sapellido==nombres){
				val=1;
				localStorage.setItem('paciente', JSON.stringify(pacientes[q]));
			}
		}
		if(val==1){
			alert('Paciente encontrado!..');
			
			
		}else{
			var varDataIn= {'cc': tipodoc, 
							'id': doc,
							'key':'GimmidsApp'
						};

			console.log(varDataIn);
			$.ajax({
				url: "https://api.gimmids.com/pruebas/servicios/buscarPaciente.php",
				type: "post",
				data: varDataIn,
				async:false
			}).done(function(res){
				console.log(res);
				try {
					var data=JSON.parse(res) 
					console.log(data); 
					if (data.STATUS == 'OK') {
						if (data.DATA.length > 0) {
							localStorage.setItem('paciente', JSON.stringify(data.DATA[data.DATA.length - 1]));
								 			
							pacientes.push(data.DATA[data.DATA.length - 1])
							fs.writeFileSync(__dirname+'/json/pacientes.json', JSON.stringify(pacientes));
							alert('Paciente encontrado!..');
						}
						
					} else {
						console.log(data);  
						
						alert(data.ERROR +' Error al listar consultas desde el servidor');
						
						
					}
		
		
				} catch (error) {
					alert('Error al listar consultas desde el servidor');
				}
		
		
			} ).fail(function() { 
				alert('Error al listar consultas gestantes desde el servidor');
			});
			

		}
		var dataATen={ 'id': id, 'estado': 1,'key':'GimmidsApp'  };
		console.log(dataATen);
		$.ajax({
			url: "https://api.gimmids.com/pruebas/servicios/actualizarEstadoAdmision.php",
			type: "post",
			data: { 'datos': dataATen},
			async:false
		}).done(function(res){
			console.log(res);
			try {
				var data=JSON.parse(res) 
				console.log(data); 
				if (data.STATUS == 'OK') {
					 
					alert('atención confirmada!...');
					ipc.send('ventana-hija', 'paciente');
				} else {
					console.log(data);  
					
					alert(data.ERROR +' Error ');
					
					
				}
	
	
			} catch (error) {
				alert('Error  ');
			}
	
	
		} ).fail(function() { 
			alert('Error');
		});


		//ipc.send('ventana-hija', 'paciente');
	}

}
function cancelarConsulta(id){
	if (confirm('Confirmar la cancelación!...')) {
		var dataIn = { 'id':  id, 'estado': 2,'key':'GimmidsApp'  };
		console.log(dataIn);
		$.post('https://api.gimmids.com/pruebas/servicios/actualizarEstadoAdmision.php', { 'datos': dataIn }, function(data) {
			console.log(data);
			if (data.STATUS == 'OK') {
				alert('Control cancelado exitosamente!...');
				location.reload();
			} else {
				alert('Error al cancelar Control!...')
			}
		}, "JSON").fail(function(err) {
			alert('Error en la conexion al servidor!..');
		});
	}
}

function exportTableToExcel(tipo){
	console.log(tipo);
	ipc.send('guardar', tipo);
	
	
}




ipc.on('guardarRecibe', function(event, tipo, files){
	if(tipo=='Pacientes servidor'){
		console.log(files[0]);
		ruta=files[0]+'\\Pacientes servidor.xlsx';
		console.log(ruta);
	   // Create a new instance of a Workbook class
		var workbook = new Excel.Workbook();

		// Add Worksheets to the workbook
		var worksheet = workbook.addWorksheet('Pacientes GIMMIDS'); 

		// Create a reusable style
		var style = workbook.createStyle({
		font: {
			color: '#F9F9F9',
			size: 14
		},
		fill:{
			type: 'pattern',
			patternType: 'solid',
			bgColor: '#507BC5',
			fgColor: '#507BC5'
			
		}});

		var contCol=1;
		var contFila=1;
		// Set value of cell A1 to 100 as a number type styled with paramaters of style
		worksheet.cell(contCol,contFila++).string('TIPO ID').style(style);
		worksheet.cell(contCol,contFila++).string('IDENTIFICACIÓN').style(style);
		worksheet.cell(contCol,contFila++).string('Otro documento').style(style);
		worksheet.cell(contCol,contFila++).string('NOMBRES').style(style);
		worksheet.cell(contCol,contFila++).string('Estado civil').style(style);
		worksheet.cell(contCol,contFila++).string('SEXO').style(style);
		worksheet.cell(contCol,contFila++).string('FECHA NACIMIENTO').style(style);
		worksheet.cell(contCol,contFila++).string('STATUS').style(style);
		worksheet.cell(contCol,contFila++).string('TIPO POBLACION').style(style);
		worksheet.cell(contCol,contFila++).string('Perfil').style(style);
		worksheet.cell(contCol,contFila++).string('Movilidad').style(style);
		worksheet.cell(contCol,contFila++).string('TELEFONO').style(style);
		worksheet.cell(contCol,contFila++).string('DIRECCIÓN').style(style);
		worksheet.cell(contCol,contFila++).string('ZONA').style(style);
		worksheet.cell(contCol,contFila++).string('PAIS PROCEDENCIA').style(style);
		worksheet.cell(contCol,contFila++).string('DPTO PROCEDENCIA').style(style);
		worksheet.cell(contCol,contFila++).string('MNP PROCEDENCIA').style(style);
		worksheet.cell(contCol,contFila++).string('BDUA').style(style);
		worksheet.cell(contCol,contFila++).string('EAPB').style(style);
		worksheet.cell(contCol,contFila++).string('tiempo ingreso a colombia').style(style);
		worksheet.cell(contCol,contFila++).string('Regimen').style(style);
		worksheet.cell(contCol,contFila++).string('Pertenencia etnica').style(style);
		worksheet.cell(contCol,contFila++).string('EMAIL').style(style);
		worksheet.cell(contCol,contFila++).string('Fecha registro').style(style); 
		
		for(var i=0;i<pacientesServidor.length;i++){
			contCol++;
			contFila=1;
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].tipoidRegPac);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].idRegPac);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].otroDocumRep);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].nombres + ' ' + pacientesServidor[i].papellido + ' ' + pacientesServidor[i].sapellido);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].estCivil);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].sexo);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].fecNac);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].status_migratorio);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].tipoPoblacion);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].perfilPacie);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].movilidadPacie);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].telefono);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].direccionResidencia);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].zonaResidencia);
			worksheet.cell(contCol,contFila++).string(listadoseleccionPais(pacientesServidor[i].paisProcedencia));
			worksheet.cell(contCol,contFila++).string(listadoseleccionDpto(pacientesServidor[i].paisProcedencia,pacientesServidor[i].dptoProcedencia));
			worksheet.cell(contCol,contFila++).string(listadoseleccionMnpo(pacientesServidor[i].paisProcedencia,pacientesServidor[i].dptoProcedencia,pacientesServidor[i].mnpoProcedencia)); 
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].BDUA);
			worksheet.cell(contCol,contFila++).string(listadoseleccionEAPB(pacientesServidor[i].eapb));
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].tiemrpoingresoColo);
			worksheet.cell(contCol,contFila++).string(listadoseleccionReg(pacientesServidor[i].regimen));
			worksheet.cell(contCol,contFila++).string(listadoseleccionEtnia(pacientesServidor[i].perEtnica));
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].correoElec);
			worksheet.cell(contCol,contFila++).string(pacientesServidor[i].fecha_registro);
		}
		
		//worksheet.cell(3,1).bool(true).style(style).style({font: {size: 14}});
		
		 
		workbook.write(ruta, function(err, stats) {
			if (err) {
			  console.error(err);
			  alert('Error al general archivo!..');
			} else {
			  console.log(stats);
			  alert('Archivo generado con exito!..');
			  
			}
		});
  
	}
	if(tipo=='Consultas servidor'){

		console.log(files[0]);
		ruta=files[0]+'\\Consultas servidor.xlsx';
		console.log(ruta);
	   	// Create a new instance of a Workbook class
		var workbook = new Excel.Workbook();

		// Add Worksheets to the workbook
		var worksheet = workbook.addWorksheet('Consultas GIMMIDS'); 

		// Create a reusable style
		var style = workbook.createStyle({
		font: {
			color: '#F9F9F9',
			size: 14
		},
		fill:{
			type: 'pattern',
			patternType: 'solid',
			bgColor: '#507BC5',
			fgColor: '#507BC5'
			
		}});
		

		var contCol=1;
		var contFila=1;

		worksheet.cell(contCol,contFila++).string('TIPO CONSULTA').style(style);
		worksheet.cell(contCol,contFila++).string('FECHA CONSULTA').style(style);
		worksheet.cell(contCol,contFila++).string('NOMBRES').style(style);
		worksheet.cell(contCol,contFila++).string('TIPO ID').style(style);
		worksheet.cell(contCol,contFila++).string('IDENTIFICACION').style(style);
		worksheet.cell(contCol,contFila++).string('MOTIVO CONSULTA').style(style);
		worksheet.cell(contCol,contFila++).string('TIPO CONSULTA').style(style);
		worksheet.cell(contCol,contFila++).string('FINALIDAD').style(style); 
		worksheet.cell(contCol,contFila++).string('CAUSA EXTERNA').style(style); 
		worksheet.cell(contCol,contFila++).string('DIAGNOSTICOS').style(style);  
		worksheet.cell(contCol,contFila++).string('Tipo Dx Principal').style(style); 
		worksheet.cell(contCol,contFila++).string('PROFESIONAL ATIENDE').style(style);  
		
		for(var t=0;t<generalServidor.DATA.length;t++){
			contCol++;
			contFila=1;

			worksheet.cell(contCol,contFila++).string('GENERAL').style(style);
			worksheet.cell(contCol,contFila++).string(generalServidor.DATA[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(generalServidor.DATA[t].nombres+' '+generalServidor.DATA[t].papellido+' '+generalServidor.DATA[t].sapellido);
			worksheet.cell(contCol,contFila++).string(generalServidor.DATA[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(generalServidor.DATA[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(generalServidor.DATA[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(generalServidor.DATA[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(generalServidor.DATA[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(generalServidor.DATA[t].causaExternaConsulta);
			if(generalServidor.DATA[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(generalServidor.DATA[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(generalServidor.DATA[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(generalServidor.DATA[t].profAtiende);
			
			
		}
		for(var t=0;t<enfermeriaServidor.DATA.length;t++){
			contCol++;
			contFila=1;

			worksheet.cell(contCol,contFila++).string('ENFERMERIA').style(style);
			worksheet.cell(contCol,contFila++).string(enfermeriaServidor.DATA[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(enfermeriaServidor.DATA[t].nombres+' '+enfermeriaServidor.DATA[t].papellido+' '+enfermeriaServidor.DATA[t].sapellido);
			worksheet.cell(contCol,contFila++).string(enfermeriaServidor.DATA[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(enfermeriaServidor.DATA[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(enfermeriaServidor.DATA[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(enfermeriaServidor.DATA[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(enfermeriaServidor.DATA[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(enfermeriaServidor.DATA[t].causaExternaConsulta);
			if(enfermeriaServidor.DATA[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(enfermeriaServidor.DATA[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(enfermeriaServidor.DATA[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(enfermeriaServidor.DATA[t].profAtiende);
			
			
		}
		for(var t=0;t<psicologiaServidor.DATA.length;t++){
			contCol++;
			contFila=1;

			worksheet.cell(contCol,contFila++).string('PSICOLOGIA').style(style);
			worksheet.cell(contCol,contFila++).string(psicologiaServidor.DATA[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(psicologiaServidor.DATA[t].nombres+' '+psicologiaServidor.DATA[t].papellido+' '+psicologiaServidor.DATA[t].sapellido);
			worksheet.cell(contCol,contFila++).string(psicologiaServidor.DATA[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(psicologiaServidor.DATA[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(psicologiaServidor.DATA[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(psicologiaServidor.DATA[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(psicologiaServidor.DATA[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(psicologiaServidor.DATA[t].causaExternaConsulta);
			if(psicologiaServidor.DATA[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(psicologiaServidor.DATA[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(psicologiaServidor.DATA[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(psicologiaServidor.DATA[t].profAtiende);
			
			
		}

		for(var t=0;t<nutricionalServidor.DATA.length;t++){
			contCol++;
			contFila=1;

			worksheet.cell(contCol,contFila++).string('NUTRICIONAL').style(style);
			worksheet.cell(contCol,contFila++).string(nutricionalServidor.DATA[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(nutricionalServidor.DATA[t].nombres+' '+nutricionalServidor.DATA[t].papellido+' '+nutricionalServidor.DATA[t].sapellido);
			worksheet.cell(contCol,contFila++).string(nutricionalServidor.DATA[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(nutricionalServidor.DATA[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(nutricionalServidor.DATA[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(nutricionalServidor.DATA[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(nutricionalServidor.DATA[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(nutricionalServidor.DATA[t].causaExternaConsulta);
			if(nutricionalServidor.DATA[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(nutricionalServidor.DATA[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(nutricionalServidor.DATA[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(nutricionalServidor.DATA[t].profAtiende);
			
			
		}
		for(var t=0;t<adultoServidor.DATA.length;t++){
			contCol++;
			contFila=1;

			worksheet.cell(contCol,contFila++).string('ADULTO').style(style);
			worksheet.cell(contCol,contFila++).string(adultoServidor.DATA[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(adultoServidor.DATA[t].nombres+' '+adultoServidor.DATA[t].papellido+' '+adultoServidor.DATA[t].sapellido);
			worksheet.cell(contCol,contFila++).string(adultoServidor.DATA[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(adultoServidor.DATA[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(adultoServidor.DATA[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(adultoServidor.DATA[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(adultoServidor.DATA[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(adultoServidor.DATA[t].causaExternaConsulta);
			if(adultoServidor.DATA[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(adultoServidor.DATA[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(adultoServidor.DATA[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(adultoServidor.DATA[t].profAtiende);
			
			
		}
		for(var t=0;t<menorServidor.DATA.length;t++){
			contCol++;
			contFila=1;

			worksheet.cell(contCol,contFila++).string('MENOR').style(style);
			worksheet.cell(contCol,contFila++).string(menorServidor.DATA[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(menorServidor.DATA[t].nombres+' '+menorServidor.DATA[t].papellido+' '+menorServidor.DATA[t].sapellido);
			worksheet.cell(contCol,contFila++).string(menorServidor.DATA[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(menorServidor.DATA[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(menorServidor.DATA[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(menorServidor.DATA[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(menorServidor.DATA[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(menorServidor.DATA[t].causaExternaConsulta);
			if(menorServidor.DATA[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(menorServidor.DATA[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(menorServidor.DATA[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(menorServidor.DATA[t].profAtiende);
			
			
		}
		for(var t=0;t<gestanteServidor.DATA.length;t++){
			contCol++;
			contFila=1;

			worksheet.cell(contCol,contFila++).string('GESTANTE').style(style);
			worksheet.cell(contCol,contFila++).string(gestanteServidor.DATA[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(gestanteServidor.DATA[t].nombres+' '+gestanteServidor.DATA[t].papellido+' '+gestanteServidor.DATA[t].sapellido);
			worksheet.cell(contCol,contFila++).string(gestanteServidor.DATA[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(gestanteServidor.DATA[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(gestanteServidor.DATA[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(gestanteServidor.DATA[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(gestanteServidor.DATA[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(gestanteServidor.DATA[t].causaExternaConsulta);
			if(gestanteServidor.DATA[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(gestanteServidor.DATA[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(gestanteServidor.DATA[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(gestanteServidor.DATA[t].profAtiende);
			
			
		}
		 
		workbook.write(ruta, function(err, stats) {
			if (err) {
			  console.error(err);
			  alert('Error al general archivo!..');
			} else {
			  console.log(stats);
			  alert('Archivo generado con exito!..');
			  
			}
		});
		
	}
	if(tipo=='Pacientes local'){
		console.log(files[0]);
		ruta=files[0]+'\\Pacientes local.xlsx';
		console.log(ruta);
	   // Create a new instance of a Workbook class
		var workbook = new Excel.Workbook();

		// Add Worksheets to the workbook
		var worksheet = workbook.addWorksheet('Pacientes GIMMIDS'); 

		// Create a reusable style
		var style = workbook.createStyle({
		font: {
			color: '#F9F9F9',
			size: 14
		},
		fill:{
			type: 'pattern',
			patternType: 'solid',
			bgColor: '#507BC5',
			fgColor: '#507BC5'
			
		}});

		var contCol=1;
		var contFila=1;
		// Set value of cell A1 to 100 as a number type styled with paramaters of style
		worksheet.cell(contCol,contFila++).string('TIPO ID').style(style);
		worksheet.cell(contCol,contFila++).string('IDENTIFICACIÓN').style(style);
		worksheet.cell(contCol,contFila++).string('Otro documento').style(style);
		worksheet.cell(contCol,contFila++).string('NOMBRES').style(style);
		worksheet.cell(contCol,contFila++).string('Estado civil').style(style);
		worksheet.cell(contCol,contFila++).string('SEXO').style(style);
		worksheet.cell(contCol,contFila++).string('FECHA NACIMIENTO').style(style);
		worksheet.cell(contCol,contFila++).string('STATUS').style(style);
		worksheet.cell(contCol,contFila++).string('TIPO POBLACION').style(style);
		worksheet.cell(contCol,contFila++).string('Perfil').style(style);
		worksheet.cell(contCol,contFila++).string('Movilidad').style(style);
		worksheet.cell(contCol,contFila++).string('TELEFONO').style(style);
		worksheet.cell(contCol,contFila++).string('DIRECCIÓN').style(style);
		worksheet.cell(contCol,contFila++).string('ZONA').style(style);
		worksheet.cell(contCol,contFila++).string('PAIS PROCEDENCIA').style(style);
		worksheet.cell(contCol,contFila++).string('DPTO PROCEDENCIA').style(style);
		worksheet.cell(contCol,contFila++).string('MNP PROCEDENCIA').style(style);
		worksheet.cell(contCol,contFila++).string('BDUA').style(style);
		worksheet.cell(contCol,contFila++).string('EAPB').style(style);
		worksheet.cell(contCol,contFila++).string('tiempo ingreso a colombia').style(style);
		worksheet.cell(contCol,contFila++).string('Regimen').style(style);
		worksheet.cell(contCol,contFila++).string('Pertenencia etnica').style(style);
		worksheet.cell(contCol,contFila++).string('EMAIL').style(style);
		worksheet.cell(contCol,contFila++).string('Fecha registro').style(style); 
		
		for(var i=0;i<pacientes.length;i++){
			contCol++;
			contFila=1;
			worksheet.cell(contCol,contFila++).string(pacientes[i].tipoidRegPac);
			worksheet.cell(contCol,contFila++).string(pacientes[i].idRegPac);
			worksheet.cell(contCol,contFila++).string(pacientes[i].otroDocumRep);
			worksheet.cell(contCol,contFila++).string(pacientes[i].nombres + ' ' + pacientes[i].papellido + ' ' + pacientes[i].sapellido);
			worksheet.cell(contCol,contFila++).string(pacientes[i].estCivil);
			worksheet.cell(contCol,contFila++).string(pacientes[i].sexo);
			worksheet.cell(contCol,contFila++).string(pacientes[i].fecNac);
			worksheet.cell(contCol,contFila++).string(pacientes[i].status_migratorio);
			worksheet.cell(contCol,contFila++).string(pacientes[i].tipoPoblacion);
			worksheet.cell(contCol,contFila++).string(pacientes[i].perfilPacie);
			worksheet.cell(contCol,contFila++).string(pacientes[i].movilidadPacie);
			worksheet.cell(contCol,contFila++).string(pacientes[i].telefono);
			worksheet.cell(contCol,contFila++).string(pacientes[i].direccionResidencia);
			worksheet.cell(contCol,contFila++).string(pacientes[i].zonaResidencia);
			worksheet.cell(contCol,contFila++).string(listadoseleccionPais(pacientes[i].paisProcedencia));
			worksheet.cell(contCol,contFila++).string(listadoseleccionDpto(pacientes[i].paisProcedencia,pacientes[i].dptoProcedencia));
			worksheet.cell(contCol,contFila++).string(listadoseleccionMnpo(pacientes[i].paisProcedencia,pacientes[i].dptoProcedencia,pacientes[i].mnpoProcedencia)); 
			worksheet.cell(contCol,contFila++).string(pacientes[i].BDUA);
			worksheet.cell(contCol,contFila++).string(listadoseleccionEAPB(pacientes[i].eapb));
			worksheet.cell(contCol,contFila++).string(pacientes[i].tiemrpoingresoColo);
			worksheet.cell(contCol,contFila++).string(listadoseleccionReg(pacientes[i].regimen));
			worksheet.cell(contCol,contFila++).string(listadoseleccionEtnia(pacientes[i].perEtnica));
			worksheet.cell(contCol,contFila++).string(pacientes[i].correoElec);
			worksheet.cell(contCol,contFila++).string(pacientes[i].fecha_registro);
		}
		
		//worksheet.cell(3,1).bool(true).style(style).style({font: {size: 14}});
		
		 
		workbook.write(ruta, function(err, stats) {
			if (err) {
			  console.error(err);
			  alert('Error al general archivo!..');
			} else {
			  console.log(stats);
			  alert('Archivo generado con exito!..');
			  
			}
		});
	}
	if(tipo=='Consultas local'){
		console.log(files[0]);
		ruta=files[0]+'\\Consultas local.xlsx';
		console.log(ruta);
	   	// Create a new instance of a Workbook class
		var workbook = new Excel.Workbook();

		// Add Worksheets to the workbook
		var worksheet = workbook.addWorksheet('Consultas GIMMIDS'); 

		// Create a reusable style
		var style = workbook.createStyle({
		font: {
			color: '#F9F9F9',
			size: 14
		},
		fill:{
			type: 'pattern',
			patternType: 'solid',
			bgColor: '#507BC5',
			fgColor: '#507BC5'
			
		}});
		

		var contCol=1;
		var contFila=1;

		worksheet.cell(contCol,contFila++).string('TIPO CONSULTA').style(style);
		worksheet.cell(contCol,contFila++).string('FECHA CONSULTA').style(style);
		worksheet.cell(contCol,contFila++).string('NOMBRES').style(style);
		worksheet.cell(contCol,contFila++).string('TIPO ID').style(style);
		worksheet.cell(contCol,contFila++).string('IDENTIFICACION').style(style);
		worksheet.cell(contCol,contFila++).string('MOTIVO CONSULTA').style(style);
		worksheet.cell(contCol,contFila++).string('TIPO CONSULTA').style(style);
		worksheet.cell(contCol,contFila++).string('FINALIDAD').style(style); 
		worksheet.cell(contCol,contFila++).string('CAUSA EXTERNA').style(style); 
		worksheet.cell(contCol,contFila++).string('DIAGNOSTICOS').style(style);  
		worksheet.cell(contCol,contFila++).string('Tipo Dx Principal').style(style); 
		worksheet.cell(contCol,contFila++).string('PROFESIONAL ATIENDE').style(style);  
		
		for(var t=0;t<generales.length;t++){
			contCol++;
			contFila=1;
			var pacienteUs=buscarPacienteIdent(generales[t].tipoid_pac, generales[t].numid_pac);
			console.log(pacienteUs);

			worksheet.cell(contCol,contFila++).string('GENERAL').style(style);
			worksheet.cell(contCol,contFila++).string(generales[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(pacienteUs.nombres+' '+pacienteUs.papellido+' '+pacienteUs.sapellido);
			worksheet.cell(contCol,contFila++).string(generales[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(generales[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(generales[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(generales[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(generales[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(generales[t].causaExternaConsulta);
			if(generales[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(generales[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(generales[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(generales[t].profAtiende);
			
			
		}
		for(var t=0;t<enfermeria.length;t++){
			contCol++;
			contFila=1;

			var pacienteUs=buscarPacienteIdent(enfermeria[t].tipoid_pac, enfermeria[t].numid_pac);
			console.log(pacienteUs);
			worksheet.cell(contCol,contFila++).string('ENFERMERIA').style(style);
			worksheet.cell(contCol,contFila++).string(enfermeria[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(pacienteUs.nombres+' '+pacienteUs.papellido+' '+pacienteUs.sapellido);
			worksheet.cell(contCol,contFila++).string(enfermeria[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(enfermeria[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(enfermeria[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(enfermeria[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(enfermeria[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(enfermeria[t].causaExternaConsulta);
			if(enfermeria[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(enfermeria[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(enfermeria[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(enfermeria[t].profAtiende);
			
			
		}
		for(var t=0;t<psicologia.length;t++){
			contCol++;
			contFila=1;

			var pacienteUs=buscarPacienteIdent(psicologia[t].tipoid_pac, psicologia[t].numid_pac);
			console.log(pacienteUs);
			worksheet.cell(contCol,contFila++).string('PSICOLOGIA').style(style);
			worksheet.cell(contCol,contFila++).string(psicologia[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(pacienteUs.nombres+' '+pacienteUs.papellido+' '+pacienteUs.sapellido);
			worksheet.cell(contCol,contFila++).string(psicologia[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(psicologia[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(psicologia[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(psicologia[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(psicologia[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(psicologia[t].causaExternaConsulta);
			if(psicologia[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(psicologia[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(psicologia[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(psicologia[t].profAtiende);
			
			
		}

		for(var t=0;t<nutricional.length;t++){
			contCol++;
			contFila=1;

			var pacienteUs=buscarPacienteIdent(nutricional[t].tipoid_pac, nutricional[t].numid_pac);
			console.log(pacienteUs);
			worksheet.cell(contCol,contFila++).string('NUTRICIONAL').style(style);
			worksheet.cell(contCol,contFila++).string(nutricional[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(pacienteUs.nombres+' '+pacienteUs.papellido+' '+pacienteUs.sapellido);
			worksheet.cell(contCol,contFila++).string(nutricional[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(nutricional[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(nutricional[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(nutricional[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(nutricional[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(nutricional[t].causaExternaConsulta);
			if(nutricional[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(nutricional[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(nutricional[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(nutricional[t].profAtiende);
			
			
		}
		for(var t=0;t<adulto.length;t++){
			contCol++;
			contFila=1;

			var pacienteUs=buscarPacienteIdent(adulto[t].tipoid_pac, adulto[t].numid_pac);
			console.log(pacienteUs);
			worksheet.cell(contCol,contFila++).string('ADULTO').style(style);
			worksheet.cell(contCol,contFila++).string(adulto[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(pacienteUs.nombres+' '+pacienteUs.papellido+' '+pacienteUs.sapellido);
			worksheet.cell(contCol,contFila++).string(adulto[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(adulto[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(adulto[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(adulto[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(adulto[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(adulto[t].causaExternaConsulta);
			if(adulto[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(adulto[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(adulto[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(adulto[t].profAtiende);
			
			
		}
		for(var t=0;t<menor.length;t++){
			contCol++;
			contFila=1;

			var pacienteUs=buscarPacienteIdent(menor[t].tipoid_pac, menor[t].numid_pac);
			console.log(pacienteUs);
			worksheet.cell(contCol,contFila++).string('MENOR').style(style);
			worksheet.cell(contCol,contFila++).string(menor[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(pacienteUs.nombres+' '+pacienteUs.papellido+' '+pacienteUs.sapellido);
			worksheet.cell(contCol,contFila++).string(menor[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(menor[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(menor[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(menor[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(menor[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(menor[t].causaExternaConsulta);
			if(menor[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(menor[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(menor[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(menor[t].profAtiende);
			
			
		}
		for(var t=0;t<gestante.length;t++){
			contCol++;
			contFila=1;

			var pacienteUs=buscarPacienteIdent(gestante[t].tipoid_pac, gestante[t].numid_pac);
			console.log(pacienteUs);
			worksheet.cell(contCol,contFila++).string('GESTANTE').style(style);
			worksheet.cell(contCol,contFila++).string(gestante[t].fechaConsulta);
			worksheet.cell(contCol,contFila++).string(pacienteUs.nombres+' '+pacienteUs.papellido+' '+pacienteUs.sapellido);
			worksheet.cell(contCol,contFila++).string(gestante[t].tipoid_pac);
			worksheet.cell(contCol,contFila++).string(gestante[t].numid_pac);
			worksheet.cell(contCol,contFila++).string(gestante[t].motivoConsulta);
			worksheet.cell(contCol,contFila++).string(gestante[t].tipoConsulta);
			worksheet.cell(contCol,contFila++).string(gestante[t].finalidadConsulta);
			worksheet.cell(contCol,contFila++).string(gestante[t].causaExternaConsulta);
			if(gestante[t].listadoCIEPa!=''){
				tddiagnostConsultasPacien = decodificarGimmids(gestante[t].listadoCIEPa);
				var contConsultas='';
				for (var q = 0; q < tddiagnostConsultasPacien.length-1; q++) {
					contConsultas +=tddiagnostConsultasPacien[q][0] + ' ' + tddiagnostConsultasPacien[q][1]+', ';
				}
			}else{
				contConsultas +='SIN DX';
			}

			worksheet.cell(contCol,contFila++).string(contConsultas);
			worksheet.cell(contCol,contFila++).string(gestante[t].tipoDiagnosPrinc);
			worksheet.cell(contCol,contFila++).string(gestante[t].profAtiende);
			
			
		}
		 
		workbook.write(ruta, function(err, stats) {
			if (err) {
			  console.error(err);
			  alert('Error al general archivo!..');
			} else {
			  console.log(stats);
			  alert('Archivo generado con exito!..');
			  
			}
		});
	}
});


function COMPARARjson(){
    
	//const pacientes1= JSON.parse(fs.readFileSync(__dirname+'/json/consultas_generales.json', 'utf-8'));
	//fs.writeFileSync(__dirname+'/json/consultas_generales.json', JSON.stringify(generales));
	
	fs.readdir(__dirname+'/json/pacients', function (err, archivos) { 
		if (err) {
			onError(err);
			return;
		}

		console.log(archivos); 
		finalpaccom1=JSON.parse(fs.readFileSync(__dirname+'/json/pacients/'+archivos[0], 'utf-8')); 
		finalpaccom=[];
		console.log(finalpaccom1.length);
		console.log(finalpaccom.length);
		for(var t=0;t<finalpaccom1.length;t++){ 
			var valpac=0;
			for(var w=0;w<finalpaccom.length;w++){
				if(finalpaccom1[t].tipoidRegPac==finalpaccom[w].tipoidRegPac && finalpaccom1[t].idRegPac==finalpaccom[w].idRegPac && finalpaccom1[t].nombres==finalpaccom[w].nombres && finalpaccom1[t].papellido==finalpaccom[w].papellido && finalpaccom1[t].sapellido==finalpaccom[w].sapellido && finalpaccom1[t].sexo==finalpaccom[w].sexo && finalpaccom1[t].fecNac==finalpaccom[w].fecNac){
					valpac=1; 
					console.log('igual');
				}
			}
			if(valpac==0){
				finalpaccom.push(finalpaccom1[t]);
			}
		}
		
		console.log(finalpaccom1.length);
		console.log(finalpaccom.length);

		console.log('----------------------------');
 

		 
		console.log(finalpaccom.length);
		for(i=1;i<archivos.length;i++){
			console.log(__dirname+'/json/pacients/'+archivos[i]);
			pacientcompa=JSON.parse(fs.readFileSync(__dirname+'/json/pacients/'+archivos[i], 'utf-8'));
			console.log(pacientcompa.length);
			for(var t=0;t<pacientcompa.length;t++){ 
				var valpac=0;
				for(var w=0;w<finalpaccom.length;w++){
					if(pacientcompa[t].tipoidRegPac==finalpaccom[w].tipoidRegPac && pacientcompa[t].idRegPac==finalpaccom[w].idRegPac && pacientcompa[t].nombres==finalpaccom[w].nombres && pacientcompa[t].papellido==finalpaccom[w].papellido && pacientcompa[t].sapellido==finalpaccom[w].sapellido && pacientcompa[t].sexo==finalpaccom[w].sexo && pacientcompa[t].fecNac==finalpaccom[w].fecNac){
						valpac=1;
					}
				}
				if(valpac==0){
					finalpaccom.push(pacientcompa[t]);
				}
			}
		}
		console.log(finalpaccom.length);
		fs.writeFileSync(__dirname+'/json/final/pacientes.json', JSON.stringify(finalpaccom));

 

	});





}